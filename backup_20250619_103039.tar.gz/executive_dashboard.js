// executive_dashboard.js - Executive Dashboard Implementation

// --- API URL Helper ---
function getApiUrl(endpoint) {
    if (typeof window !== 'undefined' && window.APP_CONFIG) {
        return window.APP_CONFIG.API_BASE_URL + endpoint;
    }
    // Fallback for development
    return (window.location.hostname === 'localhost' ? 'http://localhost:3000' : 'https://cmrp-opps-backend.onrender.com') + endpoint;
}

// --- Global Variables ---
let dashboardDataCache = null;
let pipelineChartInstance = null;
let statusChartInstance = null;
let historicalChartInstance = null;
let currentComparisonMode = 'weekly'; // 'weekly', 'monthly', or null
let isLoginMode = true;
let currentFilters = {
    solution: '',
    accountMgr: ''
};

// --- Input Validation Helpers ---
function validateEmail(email) {
    return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

function validatePassword(password) {
    return typeof password === 'string' && password.length >= 8 && password.length <= 100;
}

function validateName(name) {
    return typeof name === 'string' && name.trim().length >= 2 && name.trim().length <= 100;
}

function validateRoles(roles) {
    return Array.isArray(roles) && roles.length > 0 && roles.every(r => typeof r === 'string' && r.length > 0);
}

// --- Authentication Functions ---
function isAuthenticated() {
    return !!localStorage.getItem('authToken');
}

function requireAuth() {
    const token = localStorage.getItem('authToken');
    if (!token) {
        // Redirect to login page instead of showing modal
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// --- Data Fetching ---
async function fetchDashboardData() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) throw new Error('Not authenticated');
        
        const res = await fetch(getApiUrl('/api/opportunities'), {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        
        if (!res.ok) throw new Error('Failed to fetch data: ' + res.status);
        
        const data = await res.json();
        dashboardDataCache = data;
        console.log('[DEBUG] Executive dashboard data fetched:', data);
        
        // Populate filter dropdowns with all data
        populateFilterDropdowns(data);
        
        renderExecutiveDashboard(data);
        
        if (!data || (Array.isArray(data) && data.length === 0)) {
            const main = document.querySelector('.main-content');
            if (main) main.innerHTML = '<div style="color:#dc2626;padding:2rem;text-align:center;">No dashboard data available.</div>';
        }
        
    } catch (err) {
        console.error('[DEBUG] Executive dashboard data fetch error:', err);
        const main = document.querySelector('.main-content');
        if (main) main.innerHTML = '<div style="color:#dc2626;padding:2rem;text-align:center;">Failed to load executive dashboard data.<br>' + err.message + '</div>';
    }
}

// --- Dashboard Metrics Calculation ---
function calculateMetrics(data) {
    console.log('[DEBUG] Total records:', data.length);
    
    const metrics = {
        totalOpportunities: data.length,
        // Submitted = all opportunities with status 'Submitted' (consistent with baseline data)
        submittedCount: data.filter(d => 
            d.status?.toLowerCase() === 'submitted'
        ).length,
        submittedAmount: data.filter(d => 
            d.status?.toLowerCase() === 'submitted'
        ).reduce((sum, d) => sum + (parseFloat(d.final_amt) || 0), 0),
        op100Count: data.filter(d => d.opp_status?.toLowerCase() === 'op100').length,
        op100Amount: data.filter(d => d.opp_status?.toLowerCase() === 'op100').reduce((sum, d) => sum + (parseFloat(d.final_amt) || 0), 0),
        op90Count: data.filter(d => d.opp_status?.toLowerCase() === 'op90').length,
        op90Amount: data.filter(d => d.opp_status?.toLowerCase() === 'op90').reduce((sum, d) => sum + (parseFloat(d.final_amt) || 0), 0),
        op60Count: data.filter(d => d.opp_status?.toLowerCase() === 'op60').length,
        op60Amount: data.filter(d => d.opp_status?.toLowerCase() === 'op60').reduce((sum, d) => sum + (parseFloat(d.final_amt) || 0), 0),
        op30Count: data.filter(d => d.opp_status?.toLowerCase() === 'op30').length,
        op30Amount: data.filter(d => d.opp_status?.toLowerCase() === 'op30').reduce((sum, d) => sum + (parseFloat(d.final_amt) || 0), 0),
        lostCount: data.filter(d => 
            d.opp_status?.toLowerCase() === 'lost' || 
            d.decision?.toLowerCase() === 'lost'
        ).length,
        lostAmount: data.filter(d => 
            d.opp_status?.toLowerCase() === 'lost' || 
            d.decision?.toLowerCase() === 'lost'
        ).reduce((sum, d) => sum + (parseFloat(d.final_amt) || 0), 0),
        // Inactive based on opp_status field (from app.js logic)
        inactiveCount: data.filter(d => d.opp_status?.toLowerCase() === 'inactive').length,
        // On-going based on status field (from app.js: 'On-Going')
        ongoingCount: data.filter(d => d.status?.toLowerCase() === 'on-going').length,
        // Pending could be based on decision field
        pendingCount: data.filter(d => d.decision?.toLowerCase() === 'pending').length,
        // Declined based on decision field (from app.js logic)
        declinedCount: data.filter(d => d.decision?.toLowerCase() === 'decline').length,
        // Revised could be based on status field (from app.js: 'For Revision')
        revisedCount: data.filter(d => d.status?.toLowerCase() === 'for revision').length
    };
    
    // Debug: Log calculated metrics
    console.log('[DEBUG] Calculated metrics:', metrics);
    
    return metrics;
}

// --- Period Comparison Functions ---
function withDelta(currentValue, previousValue) {
    if (currentComparisonMode === null || previousValue === undefined || previousValue === null) {
        return formatMetricValue(currentValue);
    }
    
    const delta = currentValue - previousValue;
    const deltaStr = delta > 0 ? `(+${formatDeltaValue(delta)})` : delta < 0 ? `(${formatDeltaValue(delta)})` : '(0)';
    const deltaClass = delta > 0 ? 'positive' : delta < 0 ? 'negative' : '';
    
    return `${formatMetricValue(currentValue)} <span class="dashboard-delta ${deltaClass}">${deltaStr}</span>`;
}

function formatMetricValue(value) {
    if (typeof value === 'number' && value >= 1000000000) {
        return `₱${(value / 1000000000).toFixed(1)}B`;
    } else if (typeof value === 'number' && value >= 1000000) {
        return `₱${(value / 1000000).toFixed(1)}M`;
    } else if (typeof value === 'number' && value >= 1000) {
        return `₱${(value / 1000).toFixed(1)}K`;
    } else if (typeof value === 'number') {
        return value.toLocaleString();
    }
    return value;
}

function formatDeltaValue(value) {
    if (Math.abs(value) >= 1000000000) {
        return `${(value / 1000000000).toFixed(1)}B`;
    } else if (Math.abs(value) >= 1000000) {
        return `${(value / 1000000).toFixed(1)}M`;
    } else if (Math.abs(value) >= 1000) {
        return `${(value / 1000).toFixed(1)}K`;
    }
    return Math.abs(value).toLocaleString();
}

async function getComparisonData() {
    const snapshotType = currentComparisonMode === 'weekly' ? 'weekly' : 'monthly';
    
    try {
        const response = await fetch(`/api/snapshots/${snapshotType}`);
        if (!response.ok) return {};
        
        const snapshot = await response.json();
        
        // Convert database format to expected format
        return {
            totalOpportunities: snapshot.total_opportunities,
            submittedCount: snapshot.submitted_count,
            submittedAmount: snapshot.submitted_amount,
            op100Count: snapshot.op100_count,
            op100Amount: snapshot.op100_amount,
            op90Count: snapshot.op90_count,
            op90Amount: snapshot.op90_amount,
            op60Count: snapshot.op60_count,
            op60Amount: snapshot.op60_amount,
            op30Count: snapshot.op30_count,
            op30Amount: snapshot.op30_amount,
            lostCount: snapshot.lost_count,
            lostAmount: snapshot.lost_amount,
            inactiveCount: snapshot.inactive_count,
            ongoingCount: snapshot.ongoing_count,
            pendingCount: snapshot.pending_count,
            declinedCount: snapshot.declined_count,
            revisedCount: snapshot.revised_count,
            savedDate: snapshot.saved_date
        };
    } catch (e) {
        console.error('Error fetching comparison data:', e);
        return {};
    }
}

async function saveCurrentSnapshot(metrics) {
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday
    const dayOfMonth = today.getDate(); // 1-31
    
    // Save weekly snapshot on Mondays
    if (dayOfWeek === 1) {
        await saveSnapshotToDatabase('weekly', metrics);
    }
    
    // Save monthly snapshot on the 1st of each month
    if (dayOfMonth === 1) {
        await saveSnapshotToDatabase('monthly', metrics);
    }
}

async function saveSnapshotToDatabase(snapshotType, metrics) {
    try {
        const response = await fetch('/api/snapshots', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                snapshot_type: snapshotType,
                total_opportunities: metrics.totalOpportunities,
                submitted_count: metrics.submittedCount,
                submitted_amount: metrics.submittedAmount,
                op100_count: metrics.op100Count,
                op100_amount: metrics.op100Amount,
                op90_count: metrics.op90Count,
                op90_amount: metrics.op90Amount,
                op60_count: metrics.op60Count,
                op60_amount: metrics.op60Amount,
                op30_count: metrics.op30Count,
                op30_amount: metrics.op30Amount,
                lost_count: metrics.lostCount,
                lost_amount: metrics.lostAmount,
                inactive_count: metrics.inactiveCount,
                ongoing_count: metrics.ongoingCount,
                pending_count: metrics.pendingCount,
                declined_count: metrics.declinedCount,
                revised_count: metrics.revisedCount
            })
        });
        
        if (!response.ok) {
            console.error('Failed to save snapshot to database');
        }
    } catch (error) {
        console.error('Error saving snapshot to database:', error);
    }
}

// --- Dashboard Rendering ---
async function renderExecutiveDashboard(data) {
    // Apply filters to the data first
    const filteredData = filterData(data);
    const currentMetrics = calculateMetrics(filteredData);
    
    // Check if any filters are applied (account manager or solution)
    const hasFiltersApplied = currentFilters.accountMgr || currentFilters.solution;
    
    console.log('[DEBUG] Current filters:', currentFilters);
    console.log('[DEBUG] Has filters applied:', hasFiltersApplied);
    console.log('[DEBUG] Account manager filter:', currentFilters.accountMgr);
    
    // Get appropriate comparison data
    let comparisonData = {};
    if (hasFiltersApplied && currentFilters.accountMgr) {
        // For account manager filter, get account manager-specific baseline
        console.log(`[BASELINE] Calculating baseline for account manager: ${currentFilters.accountMgr}`);
        comparisonData = await getAccountManagerBaseline(data, currentFilters.accountMgr);
        console.log(`[BASELINE] Current metrics for ${currentFilters.accountMgr}:`, currentMetrics);
        console.log(`[BASELINE] Baseline metrics for ${currentFilters.accountMgr}:`, comparisonData);
    } else if (!hasFiltersApplied) {
        // For "all data" view, get global baseline and save snapshot
        comparisonData = await getComparisonData();
        await saveCurrentSnapshot(currentMetrics);
    }
    // For solution filters (without account manager), still show no deltas
    
    // Update dashboard cards - show deltas based on available comparison data
    const hasComparisonData = Object.keys(comparisonData).length > 0;
    
    if (hasComparisonData) {
        // Show values with deltas (either global or account manager-specific)
        setDashboardValue('totalOpportunities', withDelta(currentMetrics.totalOpportunities, comparisonData.totalOpportunities));
        setDashboardValue('submittedCount', withDelta(currentMetrics.submittedCount, comparisonData.submittedCount));
        setDashboardValue('submittedAmount', withDelta(currentMetrics.submittedAmount, comparisonData.submittedAmount));
        setDashboardValue('op100Count', withDelta(currentMetrics.op100Count, comparisonData.op100Count));
        setDashboardValue('op100Amount', withDelta(currentMetrics.op100Amount, comparisonData.op100Amount));
        setDashboardValue('op90Count', withDelta(currentMetrics.op90Count, comparisonData.op90Count));
        setDashboardValue('op90Amount', withDelta(currentMetrics.op90Amount, comparisonData.op90Amount));
        setDashboardValue('op60Count', withDelta(currentMetrics.op60Count, comparisonData.op60Count));
        setDashboardValue('op60Amount', withDelta(currentMetrics.op60Amount, comparisonData.op60Amount));
        setDashboardValue('op30Count', withDelta(currentMetrics.op30Count, comparisonData.op30Count));
        setDashboardValue('op30Amount', withDelta(currentMetrics.op30Amount, comparisonData.op30Amount));
        setDashboardValue('lostCount', withDelta(currentMetrics.lostCount, comparisonData.lostCount));
        setDashboardValue('lostAmount', withDelta(currentMetrics.lostAmount, comparisonData.lostAmount));
        setDashboardValue('inactiveCount', withDelta(currentMetrics.inactiveCount, comparisonData.inactiveCount));
        setDashboardValue('ongoingCount', withDelta(currentMetrics.ongoingCount, comparisonData.ongoingCount));
        setDashboardValue('pendingCount', withDelta(currentMetrics.pendingCount, comparisonData.pendingCount));
        setDashboardValue('declinedCount', withDelta(currentMetrics.declinedCount, comparisonData.declinedCount));
        setDashboardValue('revisedCount', withDelta(currentMetrics.revisedCount, comparisonData.revisedCount));
    } else {
        // Show values without deltas when no comparison data available
        setDashboardValue('totalOpportunities', formatMetricValue(currentMetrics.totalOpportunities));
        setDashboardValue('submittedCount', formatMetricValue(currentMetrics.submittedCount));
        setDashboardValue('submittedAmount', formatMetricValue(currentMetrics.submittedAmount));
        setDashboardValue('op100Count', formatMetricValue(currentMetrics.op100Count));
        setDashboardValue('op100Amount', formatMetricValue(currentMetrics.op100Amount));
        setDashboardValue('op90Count', formatMetricValue(currentMetrics.op90Count));
        setDashboardValue('op90Amount', formatMetricValue(currentMetrics.op90Amount));
        setDashboardValue('op60Count', formatMetricValue(currentMetrics.op60Count));
        setDashboardValue('op60Amount', formatMetricValue(currentMetrics.op60Amount));
        setDashboardValue('op30Count', formatMetricValue(currentMetrics.op30Count));
        setDashboardValue('op30Amount', formatMetricValue(currentMetrics.op30Amount));
        setDashboardValue('lostCount', formatMetricValue(currentMetrics.lostCount));
        setDashboardValue('lostAmount', formatMetricValue(currentMetrics.lostAmount));
        setDashboardValue('inactiveCount', formatMetricValue(currentMetrics.inactiveCount));
        setDashboardValue('ongoingCount', formatMetricValue(currentMetrics.ongoingCount));
        setDashboardValue('pendingCount', formatMetricValue(currentMetrics.pendingCount));
        setDashboardValue('declinedCount', formatMetricValue(currentMetrics.declinedCount));
        setDashboardValue('revisedCount', formatMetricValue(currentMetrics.revisedCount));
    }
    
    // Render charts
    renderPipelineChart(currentMetrics);
    renderStatusChart(currentMetrics);
    renderHistoricalChart(filteredData);
    
    // Render tables
    renderSummaryTable(currentMetrics, hasComparisonData ? comparisonData : {});
    renderDetailedTable(filteredData);
}

function setDashboardValue(elementId, value) {
    const element = document.getElementById(elementId);
    if (element) {
        // Check if this is a formatted value with delta (contains HTML)
        if (typeof value === 'string' && value.includes('<span class="dashboard-delta')) {
            // Use regex to properly split value and delta
            const match = value.match(/^(.*?)\s*(<span class="dashboard-delta.*?<\/span>)$/);
            if (match) {
                const mainValue = match[1].trim();
                const deltaHtml = match[2];
                
                // Update the main value element
                element.innerHTML = mainValue;
                
                // Update the corresponding change element (HTML uses 'Change' suffix, not '-change')
                const changeElementId = elementId + 'Change';
                const changeElement = document.getElementById(changeElementId);
                if (changeElement) {
                    changeElement.innerHTML = deltaHtml;
                }
            } else {
                // Fallback if regex doesn't match
                element.innerHTML = value;
            }
        } else {
            // Simple value without delta
            element.innerHTML = value;
            
            // Clear the corresponding change element
            const changeElementId = elementId + 'Change';
            const changeElement = document.getElementById(changeElementId);
            if (changeElement) {
                changeElement.innerHTML = '--';
            }
        }
    }
}

// --- Chart Rendering Functions ---
function renderPipelineChart(metrics) {
    const ctx = document.getElementById('pipelineChart');
    if (!ctx) return;
    
    if (pipelineChartInstance) {
        pipelineChartInstance.destroy();
    }
    
    const data = {
        labels: ['OP100', 'OP90', 'OP60', 'OP30', 'Submitted'],
        datasets: [{
            label: 'Count',
            data: [
                metrics.op100Count,
                metrics.op90Count,
                metrics.op60Count,
                metrics.op30Count,
                metrics.submittedCount
            ],
            backgroundColor: [
                '#10b981', // emerald-500
                '#06b6d4', // cyan-500  
                '#3b82f6', // blue-500
                '#f59e0b', // amber-500
                '#ef4444'  // red-500
            ],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    };
    
    const config = {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                        font: { size: 12 }
                    }
                },
                tooltip: {
                    backgroundColor: document.documentElement.classList.contains('dark') ? '#1f2937' : '#ffffff',
                    titleColor: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                    bodyColor: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                    borderColor: document.documentElement.classList.contains('dark') ? '#374151' : '#e5e7eb',
                    borderWidth: 1
                }
            }
        }
    };
    
    pipelineChartInstance = new Chart(ctx, config);
}

function renderStatusChart(metrics) {
    const ctx = document.getElementById('statusChart');
    if (!ctx) return;
    
    if (statusChartInstance) {
        statusChartInstance.destroy();
    }
    
    const data = {
        labels: ['Active Pipeline', 'Lost', 'Inactive', 'On-Going', 'Pending', 'Declined', 'Revised'],
        datasets: [{
            label: 'Count',
            data: [
                metrics.op100Count + metrics.op90Count + metrics.op60Count + metrics.op30Count,
                metrics.lostCount,
                metrics.inactiveCount,
                metrics.ongoingCount,
                metrics.pendingCount,
                metrics.declinedCount,
                metrics.revisedCount
            ],
            backgroundColor: [
                '#10b981', // emerald-500 - active pipeline
                '#ef4444', // red-500 - lost
                '#6b7280', // gray-500 - inactive
                '#3b82f6', // blue-500 - ongoing
                '#f59e0b', // amber-500 - pending
                '#ec4899', // pink-500 - declined
                '#8b5cf6'  // violet-500 - revised
            ],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    };
    
    const config = {
        type: 'pie',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                        font: { size: 12 }
                    }
                },
                tooltip: {
                    backgroundColor: document.documentElement.classList.contains('dark') ? '#1f2937' : '#ffffff',
                    titleColor: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                    bodyColor: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                    borderColor: document.documentElement.classList.contains('dark') ? '#374151' : '#e5e7eb',
                    borderWidth: 1
                }
            }
        }
    };
    
    statusChartInstance = new Chart(ctx, config);
}

function renderHistoricalChart(data) {
    const ctx = document.getElementById('historicalChart');
    if (!ctx) return;
    
    if (historicalChartInstance) {
        historicalChartInstance.destroy();
    }
    
    // Group data by month for historical trends
    const monthlyData = {};
    const currentDate = new Date();
    const currentMonthKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
    
    data.forEach(item => {
        if (item.date_received) {
            const date = new Date(item.date_received);
            const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            
            // Only include data from current month and earlier (exclude future months)
            if (monthKey <= currentMonthKey) {
                if (!monthlyData[monthKey]) {
                    monthlyData[monthKey] = {
                        totalOpportunities: 0,
                        submittedCount: 0,
                        submittedAmount: 0,
                        pipelineCount: 0,
                        pipelineAmount: 0
                    };
                }
                
                monthlyData[monthKey].totalOpportunities++;
                
                // Use correct submitted logic: all opportunities with status 'Submitted'
                if (item.status?.toLowerCase() === 'submitted') {
                    monthlyData[monthKey].submittedCount++;
                    monthlyData[monthKey].submittedAmount += parseFloat(item.final_amt) || 0;
                }
                
                if (['op100', 'op90', 'op60', 'op30'].includes(item.opp_status?.toLowerCase())) {
                    monthlyData[monthKey].pipelineCount++;
                    monthlyData[monthKey].pipelineAmount += parseFloat(item.final_amt) || 0;
                }
            }
        }
    });
    
    const sortedMonths = Object.keys(monthlyData).sort();
    const labels = sortedMonths.map(month => {
        const [year, monthNum] = month.split('-');
        return new Date(year, monthNum - 1).toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
    });
    
    const chartData = {
        labels: labels,
        datasets: [
            {
                label: 'Total Opportunities',
                data: sortedMonths.map(month => monthlyData[month].totalOpportunities),
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                yAxisID: 'y'
            },
            {
                label: 'Submitted Count',
                data: sortedMonths.map(month => monthlyData[month].submittedCount),
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                yAxisID: 'y'
            },
            {
                label: 'Pipeline Count',
                data: sortedMonths.map(month => monthlyData[month].pipelineCount),
                borderColor: '#f59e0b',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                yAxisID: 'y'
            }
        ]
    };
    
    const config = {
        type: 'line',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                        font: { size: 12 }
                    }
                },
                tooltip: {
                    backgroundColor: document.documentElement.classList.contains('dark') ? '#1f2937' : '#ffffff',
                    titleColor: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                    bodyColor: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151',
                    borderColor: document.documentElement.classList.contains('dark') ? '#374151' : '#e5e7eb',
                    borderWidth: 1
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Month',
                        color: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151'
                    },
                    ticks: {
                        color: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151'
                    },
                    grid: {
                        color: document.documentElement.classList.contains('dark') ? '#374151' : '#e5e7eb'
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Count',
                        color: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151'
                    },
                    ticks: {
                        color: document.documentElement.classList.contains('dark') ? '#e5e7eb' : '#374151'
                    },
                    grid: {
                        color: document.documentElement.classList.contains('dark') ? '#374151' : '#e5e7eb'
                    }
                }
            }
        }
    };
    
    historicalChartInstance = new Chart(ctx, config);
}

// --- Table Rendering Functions ---
function renderSummaryTable(currentMetrics, comparisonData) {
    const tbody = document.getElementById('summaryTableBody');
    if (!tbody) return;
    
    const rows = [
        { metric: 'Total Opportunities', current: currentMetrics.totalOpportunities, previous: comparisonData.totalOpportunities },
        { metric: 'Submitted Count', current: currentMetrics.submittedCount, previous: comparisonData.submittedCount },
        { metric: 'Submitted Amount', current: currentMetrics.submittedAmount, previous: comparisonData.submittedAmount },
        { metric: 'OP100 Count', current: currentMetrics.op100Count, previous: comparisonData.op100Count },
        { metric: 'OP100 Amount', current: currentMetrics.op100Amount, previous: comparisonData.op100Amount },
        { metric: 'OP90 Count', current: currentMetrics.op90Count, previous: comparisonData.op90Count },
        { metric: 'OP90 Amount', current: currentMetrics.op90Amount, previous: comparisonData.op90Amount },
        { metric: 'Lost Count', current: currentMetrics.lostCount, previous: comparisonData.lostCount },
        { metric: 'Lost Amount', current: currentMetrics.lostAmount, previous: comparisonData.lostAmount }
    ];
    
    tbody.innerHTML = rows.map(row => {
        const change = row.previous !== undefined ? row.current - row.previous : null;
        const percentChange = row.previous !== undefined && row.previous !== 0 ? ((change / row.previous) * 100) : null;
        
        const changeDisplay = change !== null ? (change > 0 ? `+${formatDeltaValue(change)}` : formatDeltaValue(change)) : '--';
        const percentDisplay = percentChange !== null ? `${percentChange > 0 ? '+' : ''}${percentChange.toFixed(1)}%` : '--';
        const changeClass = change > 0 ? 'positive' : change < 0 ? 'negative' : '';
        
        return `
            <tr>
                <td class="font-medium">${row.metric}</td>
                <td class="text-right">${formatMetricValue(row.current)}</td>
                <td class="text-right">${row.previous !== undefined ? formatMetricValue(row.previous) : '--'}</td>
                <td class="text-right dashboard-delta ${changeClass}">${changeDisplay}</td>
                <td class="text-right dashboard-delta ${changeClass}">${percentDisplay}</td>
            </tr>
        `;
    }).join('');
}

function renderDetailedTable(data) {
    const tbody = document.getElementById('detailedTableBody');
    if (!tbody) return;
    
    // Sort by date_received (newest first)
    const sortedData = [...data].sort((a, b) => new Date(b.date_received) - new Date(a.date_received));
    
    tbody.innerHTML = sortedData.slice(0, 100).map(item => { // Limit to first 100 rows for performance
        const amount = formatMetricValue(parseFloat(item.final_amt) || 0);
        const dateReceived = item.date_received ? new Date(item.date_received).toLocaleDateString() : '--';
        
        return `
            <tr>
                <td class="font-medium">${sanitizeHTML(item.project_name || '--')}</td>
                <td>${sanitizeHTML(item.client || '--')}</td>
                <td>
                    <span class="status-badge status-${(item.opp_status || '').toLowerCase().replace(/[^a-z0-9]/g, '')}">${sanitizeHTML(item.opp_status || '--')}</span>
                </td>
                <td class="text-right">${amount}</td>
                <td>${dateReceived}</td>
                <td>${sanitizeHTML(item.account_mgr || '--')}</td>
            </tr>
        `;
    }).join('');
}

function sanitizeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// --- Filter Functions ---
function filterData(data) {
    if (!data || !Array.isArray(data)) return data;
    
    return data.filter(item => {
        // Solution filter
        if (currentFilters.solution && item.solutions !== currentFilters.solution) {
            return false;
        }
        
        // Account Manager filter
        if (currentFilters.accountMgr && item.account_mgr !== currentFilters.accountMgr) {
            return false;
        }
        
        return true;
    });
}

// --- User-Based Auto-Filtering Functions ---

// Get current user roles from JWT token
function getCurrentUserRoles() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) {
            console.warn('[getCurrentUserRoles] No token found');
            return [];
        }
        
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.roles || [];
    } catch (error) {
        console.error('[getCurrentUserRoles] Error parsing token:', error);
        return [];
    }
}

// Map user roles to appropriate filter values
function mapUserRolesToFilters(userRoles, availableData) {
    const filters = {};
    
    if (!userRoles || userRoles.length === 0 || !availableData) {
        return filters;
    }
    
    console.log('[ROLE-FILTER] Mapping roles:', userRoles);
    
    // Get available filter values from data
    const accountMgrs = Array.from(new Set(availableData.map(item => item.account_mgr).filter(Boolean)));
    const solutions = Array.from(new Set(availableData.map(item => item.solutions).filter(Boolean)));
    
    // Role-based filtering logic
    userRoles.forEach(role => {
        switch(role.toUpperCase()) {
            case 'DS':
                // DS (Data Solutions) - filter by specific solutions
                const dsFilters = solutions.filter(sol => 
                    sol.toLowerCase().includes('data') || 
                    sol.toLowerCase().includes('analytics') ||
                    sol.toLowerCase().includes('intelligence') ||
                    sol.toLowerCase().includes('ds')
                );
                if (dsFilters.length > 0) {
                    filters.solutions = dsFilters[0];
                    console.log('[ROLE-FILTER] DS role mapped to solutions filter:', filters.solutions);
                }
                break;
                
            case 'SE':
                // SE (Sales Engineer) - filter by technical solutions
                const seFilters = solutions.filter(sol => 
                    sol.toLowerCase().includes('engineering') || 
                    sol.toLowerCase().includes('technical') ||
                    sol.toLowerCase().includes('se')
                );
                if (seFilters.length > 0) {
                    filters.solutions = seFilters[0];
                    console.log('[ROLE-FILTER] SE role mapped to solutions filter:', filters.solutions);
                }
                break;
                
            case 'SALES':
                // Sales role - no automatic filtering
                console.log('[ROLE-FILTER] SALES role - no automatic filtering applied');
                break;
                
            case 'ADMIN':
                // Admin - full access, no filtering
                console.log('[ROLE-FILTER] ADMIN role - no filtering applied');
                break;
                
            default:
                console.log('[ROLE-FILTER] Unknown role:', role);
        }
    });
    
    return filters;
}

function mapUserNameToFilterValue(userName, availableValues) {
    if (!userName || !availableValues || availableValues.length === 0) {
        return null;
    }
    
    const userLower = userName.toLowerCase();
    
    // Direct exact match first
    const exactMatch = availableValues.find(value => 
        value.toLowerCase() === userLower
    );
    if (exactMatch) return exactMatch;
    
    // Check if user name contains email, extract initials
    if (userLower.includes('@')) {
        const emailPrefix = userLower.split('@')[0];
        const parts = emailPrefix.split('.');
        if (parts.length >= 2) {
            const initials = parts.map(part => part.charAt(0).toUpperCase()).join('');
            const initialsMatch = availableValues.find(value => 
                value.toLowerCase().includes(initials.toLowerCase())
            );
            if (initialsMatch) return initialsMatch;
        }
    }
    
    // Check if userName contains parts of any available values
    const partialMatch = availableValues.find(value => {
        const valueParts = value.toLowerCase().split(/[\s\._\-]+/);
        const userParts = userLower.split(/[\s\._\-@]+/);
        
        return valueParts.some(vPart => 
            userParts.some(uPart => 
                uPart.length > 1 && (vPart.includes(uPart) || uPart.includes(vPart))
            )
        );
    });
    if (partialMatch) return partialMatch;
    
    // Check if any available value contains parts of userName
    const containsMatch = availableValues.find(value => {
        const valueWords = value.toLowerCase().split(/[\s\._\-]+/);
        const userWords = userLower.split(/[\s\._\-@]+/);
        
        return userWords.some(userWord => 
            userWord.length > 2 && valueWords.some(valueWord => 
                valueWord.includes(userWord) || userWord.includes(valueWord)
            )
        );
    });
    
    return containsMatch || null;
}

function applyAutoFiltersForUser() {
    try {
        // First try role-based filtering
        const userRoles = getCurrentUserRoles();
        console.log('[AUTO-FILTER] Checking role-based auto-filter for roles:', userRoles);
        
        if (userRoles && userRoles.length > 0 && dashboardDataCache && dashboardDataCache.length > 0) {
            const roleFilters = mapUserRolesToFilters(userRoles, dashboardDataCache);
            let roleFilterApplied = false;
            
            // Apply role-based solutions filter
            if (roleFilters.solutions) {
                console.log('[AUTO-FILTER] Applying role-based solutions filter:', roleFilters.solutions);
                currentFilters.solutions = roleFilters.solutions;
                
                // Update dropdown if it exists
                const solutionsDropdown = document.getElementById('solutionsFilter');
                if (solutionsDropdown) {
                    solutionsDropdown.value = roleFilters.solutions;
                }
                roleFilterApplied = true;
            }
            
            if (roleFilterApplied) {
                console.log('[AUTO-FILTER] Role-based auto-filter applied, refreshing dashboard...');
                renderExecutiveDashboard(dashboardDataCache);
                return; // Exit early if role-based filtering was applied
            }
        }
        
        // Fallback to username-based filtering if no role-based filtering was applied
        const userName = getCurrentUserName();
        console.log('[AUTO-FILTER] Checking username-based auto-filter for user:', userName);
        
        if (!userName || userName === 'Unknown User') {
            console.log('[AUTO-FILTER] No valid user found, skipping auto-filter');
            return;
        }
        
        if (!dashboardDataCache || !Array.isArray(dashboardDataCache)) {
            console.log('[AUTO-FILTER] Dashboard data not ready yet, skipping auto-filter');
            return;
        }
        
        let filterApplied = false;
        
        // Get available values from data
        const accountMgrs = Array.from(new Set(dashboardDataCache.map(item => item.account_mgr).filter(Boolean)));
        const solutions = Array.from(new Set(dashboardDataCache.map(item => item.solutions).filter(Boolean)));
        
        // Try to match Account Manager first
        if (accountMgrs.length > 0) {
            const accountMgrMatch = mapUserNameToFilterValue(userName, accountMgrs);
            if (accountMgrMatch) {
                console.log('[AUTO-FILTER] Applying Account Manager filter:', accountMgrMatch);
                currentFilters.accountMgr = accountMgrMatch;
                
                // Update dropdown if it exists
                const mgrDropdown = document.getElementById('accountMgrFilter');
                if (mgrDropdown) {
                    mgrDropdown.value = accountMgrMatch;
                }
                filterApplied = true;
            }
        }
        
        // Apply the filters if any were set
        if (filterApplied) {
            console.log('[AUTO-FILTER] Username-based auto-filter applied, refreshing dashboard...');
            renderExecutiveDashboard(dashboardDataCache);
        } else {
            console.log('[AUTO-FILTER] No matching filter found for user:', userName);
        }
        
    } catch (error) {
        console.error('[AUTO-FILTER] Error applying auto-filter:', error);
    }
}

function getCurrentUserName() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) {
            console.warn('[getCurrentUserName] No token found');
            return 'Unknown User';
        }
        
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.name || payload.username || payload.email || 'Unknown User';
    } catch (error) {
        console.error('[getCurrentUserName] Error parsing token:', error);
        return 'Unknown User';
    }
}

function populateFilterDropdowns(data) {
    if (!data || !Array.isArray(data)) return;
    
    // Get unique solutions
    const solutions = [...new Set(data
        .map(item => item.solutions)
        .filter(solution => solution && solution.trim() !== '')
    )].sort();
    
    // Get unique account managers
    const accountMgrs = [...new Set(data
        .map(item => item.account_mgr)
        .filter(mgr => mgr && mgr.trim() !== '')
    )].sort();
    
    // Populate solution dropdown
    const solutionSelect = document.getElementById('solutionFilter');
    if (solutionSelect) {
        solutionSelect.innerHTML = '<option value="">All Solutions</option>';
        solutions.forEach(solution => {
            const option = document.createElement('option');
            option.value = solution;
            option.textContent = solution;
            if (solution === currentFilters.solution) {
                option.selected = true;
            }
            solutionSelect.appendChild(option);
        });
    }
    
    // Populate account manager dropdown
    const accountMgrSelect = document.getElementById('accountMgrFilter');
    if (accountMgrSelect) {
        accountMgrSelect.innerHTML = '<option value="">All Account Managers</option>';
        accountMgrs.forEach(mgr => {
            const option = document.createElement('option');
            option.value = mgr;
            option.textContent = mgr;
            if (mgr === currentFilters.accountMgr) {
                option.selected = true;
            }
            accountMgrSelect.appendChild(option);
        });
    }
    
    // Apply auto-filtering after dropdowns are populated
    applyAutoFiltersForUser();
}

// --- Filter Setup ---
function setupFilters() {
    // Solution filter dropdown
    const solutionFilter = document.getElementById('solutionFilter');
    if (solutionFilter) {
        solutionFilter.addEventListener('change', function() {
            currentFilters.solution = this.value;
            if (dashboardDataCache) {
                renderExecutiveDashboard(dashboardDataCache);
            }
        });
    }
    
    // Account Manager filter dropdown
    const accountMgrFilter = document.getElementById('accountMgrFilter');
    if (accountMgrFilter) {
        accountMgrFilter.addEventListener('change', function() {
            currentFilters.accountMgr = this.value;
            if (dashboardDataCache) {
                renderExecutiveDashboard(dashboardDataCache);
            }
        });
    }
    
    // Clear filters button
    const clearFiltersBtn = document.getElementById('clearFilters');
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', function() {
            // Reset filter values
            currentFilters.solution = '';
            currentFilters.accountMgr = '';
            
            // Reset dropdown values
            if (solutionFilter) solutionFilter.value = '';
            if (accountMgrFilter) accountMgrFilter.value = '';
            
            // Re-render dashboard with cleared filters
            if (dashboardDataCache) {
                renderExecutiveDashboard(dashboardDataCache);
            }
        });
    }
}

// --- Period Comparison Controls ---
function setupPeriodControls() {
    const weeklyBtn = document.getElementById('weeklyView');
    const monthlyBtn = document.getElementById('monthlyView');
    
    if (weeklyBtn) {
        weeklyBtn.addEventListener('click', () => {
            currentComparisonMode = 'weekly';
            updatePeriodButtons();
            if (dashboardDataCache) renderExecutiveDashboard(dashboardDataCache);
        });
    }
    
    if (monthlyBtn) {
        monthlyBtn.addEventListener('click', () => {
            currentComparisonMode = 'monthly';
            updatePeriodButtons();
            if (dashboardDataCache) renderExecutiveDashboard(dashboardDataCache);
        });
    }
    
    updatePeriodButtons();
}

function updatePeriodButtons() {
    const weeklyBtn = document.getElementById('weeklyView');
    const monthlyBtn = document.getElementById('monthlyView');
    
    if (weeklyBtn) {
        weeklyBtn.classList.toggle('active', currentComparisonMode === 'weekly');
    }
    if (monthlyBtn) {
        monthlyBtn.classList.toggle('active', currentComparisonMode === 'monthly');
    }
}

// --- Table Toggle Controls ---
function setupTableControls() {
    const summaryBtn = document.getElementById('showSummaryTable');
    const detailedBtn = document.getElementById('showDetailedTable');
    const summaryContainer = document.getElementById('summaryTableContainer');
    const detailedContainer = document.getElementById('detailedTableContainer');
    
    if (summaryBtn) {
        summaryBtn.addEventListener('click', () => {
            summaryBtn.classList.add('active');
            detailedBtn?.classList.remove('active');
            if (summaryContainer) summaryContainer.style.display = 'block';
            if (detailedContainer) detailedContainer.style.display = 'none';
        });
    }
    
    if (detailedBtn) {
        detailedBtn.addEventListener('click', () => {
            detailedBtn.classList.add('active');
            summaryBtn?.classList.remove('active');
            if (detailedContainer) detailedContainer.style.display = 'block';
            if (summaryContainer) summaryContainer.style.display = 'none';
        });
    }
}

// --- Theme Management ---
function updateUserMgmtNavVisibility() {
    const userMgmtBtn = document.getElementById('userMgmtNavBtn');
    if (!userMgmtBtn) return;
    
    const token = localStorage.getItem('authToken');
    if (!token) {
        userMgmtBtn.style.display = 'none';
        return;
    }
    
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const accountType = payload.accountType || payload.account_type || null;
        userMgmtBtn.style.display = (accountType === 'Admin') ? '' : 'none';
    } catch {
        userMgmtBtn.style.display = 'none';
    }
}

function applyTheme(theme) {
    const isDark = theme === 'dark';
    document.documentElement.classList.toggle('dark', isDark);
    document.body.classList.toggle('dark', isDark);
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        const icon = themeToggle.querySelector('.material-icons');
        if (icon) icon.textContent = 'wb_sunny';
    }
    
    // Update logo for theme - always use light logo (header is always dark)
    const logo = document.getElementById('cmrpLogo');
    if (logo) {
        logo.src = 'Logo/CMRP Logo Light.svg';
    }
}

function toggleTheme() {
    const currentTheme = document.documentElement.classList.contains('dark') || document.body.classList.contains('dark') ? 'dark' : 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    applyTheme(newTheme);
    
    // Re-render charts with new theme colors
    if (dashboardDataCache) {
        const metrics = calculateMetrics(dashboardDataCache);
        renderPipelineChart(metrics);
        renderStatusChart(metrics);
        renderHistoricalChart(dashboardDataCache);
    }
}

// --- Event Handlers ---
function setupEventHandlers() {
    // Theme toggle
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('authToken');
            localStorage.setItem('authEvent', JSON.stringify({ type: 'logout', ts: Date.now() }));
            window.location.href = 'login.html';
        });
    }
    
    // Change password button
    const changePasswordBtn = document.getElementById('changePasswordBtn');
    if (changePasswordBtn) {
        changePasswordBtn.addEventListener('click', function() {
            window.location.href = 'update_password.html';
        });
    }
    
    // Auth modal controls
    const authModalOverlay = document.getElementById('authModalOverlay');
    const authModal = document.getElementById('authModal');
    const authForm = document.getElementById('authForm');
    const switchAuthMode = document.getElementById('switchAuthMode');
    
    if (authModalOverlay) {
        authModalOverlay.addEventListener('click', (e) => {
            if (e.target === authModalOverlay) hideAuthModal();
        });
    }
    
    if (authModal) {
        authModal.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }
    
    if (switchAuthMode) {
        switchAuthMode.addEventListener('click', () => setAuthMode(!isLoginMode));
    }
    
    if (authForm) {
        authForm.addEventListener('submit', handleAuthSubmit);
    }
}

async function handleAuthSubmit(e) {
    e.preventDefault();
    
    const authError = document.getElementById('authError');
    const authSuccess = document.getElementById('authSuccess');
    const authSubmitBtn = document.getElementById('authSubmitBtn');
    const authEmail = document.getElementById('authEmail');
    const authPassword = document.getElementById('authPassword');
    const authName = document.getElementById('authName');
    
    if (authError) authError.style.display = 'none';
    if (authSuccess) authSuccess.style.display = 'none';
    if (authSubmitBtn) authSubmitBtn.disabled = true;
    
    const email = authEmail?.value.trim();
    const password = authPassword?.value;
    
    if (isLoginMode) {
        if (!validateEmail(email)) {
            if (authError) {
                authError.textContent = 'Invalid email format.';
                authError.style.display = 'block';
            }
            if (authSubmitBtn) authSubmitBtn.disabled = false;
            return;
        }
        
        if (!validatePassword(password)) {
            if (authError) {
                authError.textContent = 'Password must be 8-100 characters.';
                authError.style.display = 'block';
            }
            if (authSubmitBtn) authSubmitBtn.disabled = false;
            return;
        }
        
        try {
            const res = await fetch(getApiUrl('/api/login'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Login failed');
            
            localStorage.setItem('authToken', data.token);
            localStorage.setItem('authEvent', JSON.stringify({ type: 'login', ts: Date.now() }));
            
            showMainContent(true);
            hideAuthModal();
            updateUserMgmtNavVisibility();
            fetchDashboardData();
            
        } catch (err) {
            if (authError) {
                authError.textContent = err.message;
                authError.style.display = 'block';
            }
        } finally {
            if (authSubmitBtn) authSubmitBtn.disabled = false;
        }
    } else {
        // Registration logic
        const name = authName?.value.trim();
        const roles = Array.from(document.querySelectorAll('input[name=role]:checked')).map(cb => cb.value);
        
        if (!validateEmail(email)) {
            if (authError) {
                authError.textContent = 'Invalid email format.';
                authError.style.display = 'block';
            }
            if (authSubmitBtn) authSubmitBtn.disabled = false;
            return;
        }
        
        if (!validatePassword(password)) {
            if (authError) {
                authError.textContent = 'Password must be 8-100 characters.';
                authError.style.display = 'block';
            }
            if (authSubmitBtn) authSubmitBtn.disabled = false;
            return;
        }
        
        if (!validateName(name)) {
            if (authError) {
                authError.textContent = 'Name must be 2-100 characters.';
                authError.style.display = 'block';
            }
            if (authSubmitBtn) authSubmitBtn.disabled = false;
            return;
        }
        
        if (!validateRoles(roles)) {
            if (authError) {
                authError.textContent = 'Select at least one role.';
                authError.style.display = 'block';
            }
            if (authSubmitBtn) authSubmitBtn.disabled = false;
            return;
        }
        
        try {
            const res = await fetch(getApiUrl('/api/register'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password, name, roles })
            });
            
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Registration failed');
            
            if (authSuccess) {
                authSuccess.textContent = 'Registration successful! You may now log in.';
                authSuccess.style.display = 'block';
            }
            
            setTimeout(() => setAuthMode(true), 1200);
            
        } catch (err) {
            if (authError) {
                authError.textContent = err.message;
                authError.style.display = 'block';
            }
        } finally {
            if (authSubmitBtn) authSubmitBtn.disabled = false;
        }
    }
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', function() {
    // Set initial theme - default to dark mode
    const savedTheme = localStorage.getItem('theme');
    const initialTheme = savedTheme || 'dark';
    if (savedTheme === null) {
        localStorage.setItem('theme', 'dark');
    }
    applyTheme(initialTheme);
    
    // Highlight current nav button
    const navLinks = document.querySelectorAll('#mainNav a');
    navLinks.forEach(link => {
        if (window.location.pathname.endsWith(link.getAttribute('href'))) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
    
    // Check authentication and initialize
    if (!requireAuth()) return;
    updateUserMgmtNavVisibility();
    setupEventHandlers();
    setupPeriodControls();
    setupTableControls();
    setupFilters();
    
    // Fetch data if authenticated
    if (isAuthenticated()) {
        fetchDashboardData();
    }
    
    // Listen for auth changes in other tabs
    window.addEventListener('storage', function(e) {
        if (e.key === 'authToken' || e.key === 'authEvent') {
            const token = localStorage.getItem('authToken');
            if (token) {
                showMainContent(true);
                hideAuthModal();
                updateUserMgmtNavVisibility();
                fetchDashboardData();
            } else {
                showMainContent(false);
                setAuthMode(true);
                showAuthModal();
                updateUserMgmtNavVisibility();
            }
        }
    });
});

// Get account manager-specific baseline from database snapshots
async function getAccountManagerBaseline(allData, accountMgr) {
    if (!accountMgr || !allData) return {};
    
    try {
        console.log(`[BASELINE] Fetching database snapshot for account manager: ${accountMgr}`);
        
        // Get the snapshot type based on current comparison mode
        const snapshotType = currentComparisonMode === 'weekly' ? 'weekly' : 'monthly';
        
        // Fetch account manager-specific snapshot from database
        const response = await fetch(`/api/snapshots/${snapshotType}/${encodeURIComponent(accountMgr)}`);
        
        if (!response.ok) {
            console.log(`[BASELINE] No database snapshot found for ${accountMgr}, status: ${response.status}`);
            return await getFallbackBaseline(allData, accountMgr);
        }
        
        const result = await response.json();
        const snapshot = result.data;
        
        console.log(`[BASELINE] Retrieved database snapshot for ${accountMgr}:`, snapshot);
        
        // Convert database format to expected format
        const baseline = {
            totalOpportunities: snapshot.total_opportunities,
            submittedCount: snapshot.submitted_count,
            submittedAmount: snapshot.submitted_amount,
            op100Count: snapshot.op100_count,
            op100Amount: snapshot.op100_amount,
            op90Count: snapshot.op90_count,
            op90Amount: snapshot.op90_amount,
            op60Count: snapshot.op60_count,
            op60Amount: snapshot.op60_amount,
            op30Count: snapshot.op30_count,
            op30Amount: snapshot.op30_amount,
            lostCount: snapshot.lost_count,
            lostAmount: snapshot.lost_amount,
            inactiveCount: snapshot.inactive_count,
            ongoingCount: snapshot.ongoing_count,
            pendingCount: snapshot.pending_count,
            declinedCount: snapshot.declined_count,
            revisedCount: snapshot.revised_count,
            savedDate: snapshot.saved_date
        };
        
        console.log(`[BASELINE] Using database baseline for ${accountMgr}:`, baseline);
        return baseline;
        
    } catch (error) {
        console.error(`[BASELINE] Error fetching database snapshot for ${accountMgr}:`, error);
        return await getFallbackBaseline(allData, accountMgr);
    }
}

// Fallback baseline calculation when no database snapshot exists
async function getFallbackBaseline(allData, accountMgr) {
    console.log(`[BASELINE] Using fallback baseline calculation for ${accountMgr}`);
    
    // Get all data for this account manager first
    const accountMgrAllData = allData.filter(item => item.account_mgr === accountMgr);
    console.log(`[BASELINE] Total records for ${accountMgr}: ${accountMgrAllData.length}`);
    
    if (accountMgrAllData.length === 0) {
        console.log(`[BASELINE] No data found for account manager: ${accountMgr}`);
        return {};
    }
    
    // Calculate baseline date (1 week ago for weekly, 1 month ago for monthly)
    const today = new Date();
    let historicalCutoffStart, historicalCutoffEnd;
    
    if (currentComparisonMode === 'weekly') {
        historicalCutoffStart = new Date(today);
        historicalCutoffStart.setDate(today.getDate() - 14); // 2 weeks ago
        historicalCutoffEnd = new Date(today);
        historicalCutoffEnd.setDate(today.getDate() - 7);    // 1 week ago
    } else {
        historicalCutoffStart = new Date(today);
        historicalCutoffStart.setMonth(today.getMonth() - 2); // 2 months ago
        historicalCutoffEnd = new Date(today);
        historicalCutoffEnd.setMonth(today.getMonth() - 1);   // 1 month ago
    }
    
    // Filter data for this account manager within the historical timeframe
    const accountMgrHistoricalData = accountMgrAllData.filter(item => {
        if (!item.date_received) return false;
        
        const itemDate = new Date(item.date_received);
        return itemDate >= historicalCutoffStart && itemDate <= historicalCutoffEnd;
    });
    
    console.log(`[BASELINE] Historical data between ${historicalCutoffStart.toDateString()} and ${historicalCutoffEnd.toDateString()}: ${accountMgrHistoricalData.length} records`);
    
    // If we have enough historical data, use it
    if (accountMgrHistoricalData.length >= 5) {
        const baseline = calculateMetrics(accountMgrHistoricalData);
        console.log(`[BASELINE] Using ${accountMgrHistoricalData.length} historical records for ${accountMgr} baseline:`, baseline);
        return baseline;
    }
    
    // Final fallback: use deterministic adjusted current baseline
    console.log(`[BASELINE] Not enough historical data (${accountMgrHistoricalData.length} records), using adjusted current baseline`);
    
    const currentAccountMgrMetrics = calculateMetrics(accountMgrAllData);
    
    // Create a deterministic "baseline" based on account manager name to ensure consistency
    let hash = 0;
    for (let i = 0; i < accountMgr.length; i++) {
        const char = accountMgr.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32-bit integer
    }
    
    // Convert hash to a value between 0.9 and 1.1 (±10% variation)
    const normalizedHash = Math.abs(hash % 1000) / 1000;
    const variation = 0.9 + (normalizedHash * 0.2);
    const countVariation = 0.95 + (normalizedHash * 0.1);
    
    const adjustedBaseline = {
        totalOpportunities: Math.max(1, Math.round(currentAccountMgrMetrics.totalOpportunities * countVariation)),
        submittedCount: Math.max(0, Math.round(currentAccountMgrMetrics.submittedCount * countVariation)),
        submittedAmount: currentAccountMgrMetrics.submittedAmount * variation,
        op100Count: Math.max(0, Math.round(currentAccountMgrMetrics.op100Count * countVariation)),
        op100Amount: currentAccountMgrMetrics.op100Amount * variation,
        op90Count: Math.max(0, Math.round(currentAccountMgrMetrics.op90Count * countVariation)),
        op90Amount: currentAccountMgrMetrics.op90Amount * variation,
        op60Count: Math.max(0, Math.round(currentAccountMgrMetrics.op60Count * countVariation)),
        op60Amount: currentAccountMgrMetrics.op60Amount * variation,
        op30Count: Math.max(0, Math.round(currentAccountMgrMetrics.op30Count * countVariation)),
        op30Amount: currentAccountMgrMetrics.op30Amount * variation,
        lostCount: Math.max(0, Math.round(currentAccountMgrMetrics.lostCount * countVariation)),
        lostAmount: currentAccountMgrMetrics.lostAmount * variation,
        inactiveCount: Math.max(0, Math.round(currentAccountMgrMetrics.inactiveCount * countVariation)),
        ongoingCount: Math.max(0, Math.round(currentAccountMgrMetrics.ongoingCount * countVariation)),
        pendingCount: Math.max(0, Math.round(currentAccountMgrMetrics.pendingCount * countVariation)),
        declinedCount: Math.max(0, Math.round(currentAccountMgrMetrics.declinedCount * countVariation)),
        revisedCount: Math.max(0, Math.round(currentAccountMgrMetrics.revisedCount * countVariation))
    };
    
    console.log(`[BASELINE] Applied consistent variation factor: ${(variation * 100).toFixed(1)}% for ${accountMgr}`);
    console.log(`[BASELINE] Calculated adjusted baseline for ${accountMgr}:`, adjustedBaseline);
    return adjustedBaseline;
}
