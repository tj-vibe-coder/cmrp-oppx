// --- API Configuration ---
function getApiUrl(endpoint) {
    const baseUrl = window.APP_CONFIG?.API_BASE_URL || '';
    return `${baseUrl}${endpoint}`;
}

// --- Global Variables ---
let opportunities = [];
let headers = [];
let headerIndices = {};
let particularsIndices = [];
let currentSortColumnIndex = -1;
let currentSortDirection = 'asc';
let isLoginMode = true;
let isCreateMode = false;
let currentEditRowIndex = -1;
let showACRUD = false;
let columnVisibility = {}; // Add missing global variable for column visibility

// --- DOM Elements ---
let htmlElement;
let themeToggle;
let table;
let tableHead;
let tableBody;
let loadingText;
let searchInput;
let statusFilterButtonsContainer;
let solutionsFilterDropdown;
let accountMgrFilterDropdown;
let picFilterDropdown;
let createOpportunityButton;
let exportExcelButton;
let toggleColumnsButton;
let columnToggleContainer;
let authModalOverlay;
let authModal;
let authForm;
let authEmail;
let authPassword;
let authError;
let authSuccess;
let authSubmitBtn;
let switchAuthMode;
let logoutBtn;
let totalOpportunities;
let totalSubmitted;
let op100Summary;
let op90Summary;
let totalDeclined;
let totalInactive;
let lostSummary;
let declinedSummary;

// --- Constants ---
const DROPDOWN_FIELDS = ['solutions', 'sol_particulars', 'industries', 'ind_particulars', 'decision', 'account_mgr', 'pic', 'bom', 'status', 'opp_status', 'lost_rca', 'l_particulars', 'a', 'c', 'r', 'u', 'd'];
const DROPDOWN_FIELDS_NORM = DROPDOWN_FIELDS.map(field => field.toLowerCase().replace(/[^a-z0-9]/g, ''));
const encodedDateHeaders = ['encodeddate'];
const withDayHeaders = ['datereceived', 'clientdeadline', 'submitteddate', 'dateawardedlost', 'forecastdate'];
const rightAlignColumns = ['finalamt'];
let dropdownOptions = {};

// --- Utility Functions ---
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function normalizeField(field) {
    if (!field) return '';
    return field.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function isDateField(header) {
    const norm = normalizeField(header || '');
    return encodedDateHeaders.includes(norm) || withDayHeaders.includes(norm) || norm === 'forecastdate';
}

function isCurrencyField(header) {
    return normalizeField(header || '').includes('amt');
}

function isMarginField(header) {
    return normalizeField(header || '').includes('margin');
}

function parseDateString(dateString) {
    if (!dateString) return null;
    dateString = String(dateString).trim();
    if (!dateString) return null;

    // Try parsing as ISO date first
    let date = new Date(dateString);
    if (!isNaN(date.getTime())) return date;

    // Try parsing common formats
    const formats = [
        'MM/DD/YYYY',
        'MM-DD-YYYY',
        'YYYY/MM/DD',
        'YYYY-MM-DD',
        'DD/MM/YYYY',
        'DD-MM-YYYY',
        'MMM DD, YYYY',
        'MMMM DD, YYYY',
        'DD MMM YYYY',
        'DD MMMM YYYY'
    ];

    for (let format of formats) {
        try {
            const momentDate = moment(dateString, format);
            if (momentDate.isValid()) return momentDate.toDate();
        } catch (e) {
            continue;
        }
    }

    // If all else fails, try to extract numbers and make best guess
    const numbers = dateString.match(/\d+/g);
    if (numbers && numbers.length >= 3) {
        const [n1, n2, n3] = numbers.map(n => parseInt(n));
        // Assume American format (MM/DD/YYYY) if month and day are ambiguous
        if (n1 <= 12 && n2 <= 31) {
            return new Date(n3 >= 100 ? n3 : 2000 + n3, n1 - 1, n2);
        }
    }

    console.warn(`Could not parse date string: ${dateString}`);
    return null;
}

function parseCurrency(currencyString) {
    if (!currencyString) return 0;
    if (typeof currencyString === 'number') return currencyString;
    
    // Remove currency symbols, commas, and other non-numeric characters except decimal point and minus
    const numStr = String(currencyString).replace(/[^0-9.-]/g, '');
    const value = parseFloat(numStr);
    return isNaN(value) ? 0 : value;
}

function formatDate(dateString) { // Target format: Jan-01
    try {
        let date = parseDateString(dateString);
        if (!date) return dateString;
        const month = date.toLocaleString('en-US', { month: 'short' });
        const day = String(date.getDate()).padStart(2, '0');
        return `${month}-${day}`;
    } catch (e) {
        console.error("Error formatting date (formatDate):", dateString, e);
        return dateString;
    }
}

function formatDateWithDay(dateString) { // Target format: Mon, Jan-01
    try {
        let date = parseDateString(dateString);
        if (!date) return dateString;
        const day = date.toLocaleString('en-US', { weekday: 'short' });
        const month = date.toLocaleString('en-US', { month: 'short' });
        const dayNum = String(date.getDate()).padStart(2, '0');
        return `${day}, ${month}-${dayNum}`;
    } catch (e) {
        console.error("Error formatting date (formatDateWithDay):", dateString, e);
        return dateString;
    }
}

function formatMargin(marginValue) {
    if (!marginValue && marginValue !== 0) return '';
    if (typeof marginValue === 'string') {
        if (marginValue.includes('%')) return marginValue;
        marginValue = parseFloat(marginValue);
    }
    if (isNaN(marginValue)) return '';
    return Math.round(marginValue) + '%';
}

function formatCurrency(amountValue) {
    if (!amountValue && amountValue !== 0) return '';
    const amount = parseCurrency(amountValue);
    return new Intl.NumberFormat('en-PH', {
        style: 'currency',
        currency: 'PHP',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

function formatCellValue(value, header) {
    if (value === null || value === undefined) return '';
    
    const normHeader = normalizeField(header);
    
    if (encodedDateHeaders.includes(normHeader)) {
        return formatDate(value);
    }
    
    if (withDayHeaders.includes(normHeader)) {
        return formatDateWithDay(value);
    }
    
    if (isCurrencyField(normHeader)) {
        return formatCurrency(value);
    }
    
    if (isMarginField(normHeader)) {
        return formatMargin(value);
    }
    
    return value;
}

function formatHeaderText(header) {
    if (!header) return '';
    
    // Split on camelCase
    let text = header.replace(/([A-Z])/g, ' $1');
    
    // Split on underscores and remove them
    text = text.replace(/_/g, ' ');
    
    // Capitalize first letter of each word
    text = text.split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(' ');
    
    // Handle special cases
    text = text.replace(/Amt/g, 'Amount')
        .replace(/Mgr/g, 'Manager')
        .replace(/Pic/g, 'PIC')
        .replace(/Op/g, 'OP')
        .replace(/Uid/g, 'ID')
        .replace(/Id/g, 'ID')
        .replace(/Rca/g, 'RCA');
    
    return text.trim();
}

// --- Initialize App ---
async function initializeApp() {
    try {
        const token = getAuthToken();
        if (!token) {
            throw new Error('No authentication token found');
        }

        // Show loading state
        loadingText.style.display = 'block';

        // Fetch opportunities data
        const response = await fetch(getApiUrl('/api/opportunities'), {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to fetch opportunities');
        }

        opportunities = await response.json();
        
        // Initialize the table with the data
        await initializeTable();
        
        // Load dashboard data with filtered data (respects auto-filtering)
        const filteredData = getCurrentFilteredData();
        loadDashboardData(filteredData);
        
        // Update user management nav visibility
        updateUserMgmtNavVisibility();
        
        // Update change password button visibility
        updateChangePasswordBtnVisibility();
        
        // Hide loading state
        loadingText.style.display = 'none';
        
        // Initialize dashboard comparison toggles
        initializeDashboardToggles();
        
    } catch (error) {
        console.error('[AUTH DEBUG] Error initializing app:', error);
        console.error('[AUTH DEBUG] Error message:', error.message);
        console.error('[AUTH DEBUG] Error stack:', error.stack);
        console.error('[AUTH DEBUG] Error details:', {
            name: error.name,
            message: error.message,
            stack: error.stack,
            toString: error.toString()
        });
        
        // Show detailed error to user
        const errorDetails = `
            <strong>App Initialization Error:</strong><br>
            <strong>Message:</strong> ${error.message}<br>
            <strong>Type:</strong> ${error.name}<br>
            <strong>Details:</strong> Check browser console for full stack trace
        `;
        showAuthErrorBanner(errorDetails);
        
        // Also try to show the main content anyway in case it's a non-critical error
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            mainContent.style.display = 'block';
        }
        
        // Hide loading state
        if (loadingText) {
            loadingText.style.display = 'none';
        }
        handleLogout();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialize DOM elements
    htmlElement = document.documentElement;
    themeToggle = document.getElementById('themeToggle');
    table = document.getElementById('opportunitiesTable');
    tableHead = table.querySelector('thead');
    tableBody = table.querySelector('tbody');
    loadingText = document.getElementById('loadingText');
    searchInput = document.getElementById('searchInput');
    statusFilterButtonsContainer = document.getElementById('statusFilterButtons');
    solutionsFilterDropdown = document.getElementById('solutionsFilter');
    accountMgrFilterDropdown = document.getElementById('accountMgrFilter');
    picFilterDropdown = document.getElementById('picFilter');
    createOpportunityButton = document.getElementById('createOpportunityButton');
    exportExcelButton = document.getElementById('exportExcelButton');
    toggleColumnsButton = document.getElementById('toggleColumnsButton');
    columnToggleContainer = document.getElementById('columnToggleContainer');
    authModalOverlay = document.getElementById('authModalOverlay');
    authModal = document.getElementById('authModal');
    authForm = document.getElementById('authForm');
    authEmail = document.getElementById('authEmail');
    authPassword = document.getElementById('authPassword');
    authError = document.getElementById('authError');
    authSuccess = document.getElementById('authSuccess');
    authSubmitBtn = document.getElementById('authSubmitBtn');
    switchAuthMode = document.getElementById('switchAuthMode');
    logoutBtn = document.getElementById('logoutBtn');
    totalOpportunities = document.getElementById('totalOpportunities');
    totalSubmitted = document.getElementById('totalSubmitted');
    op100Summary = document.getElementById('op100Summary');
    op90Summary = document.getElementById('op90Summary');
    totalDeclined = document.getElementById('totalDeclined');
    totalInactive = document.getElementById('totalInactive');
    lostSummary = document.getElementById('lostSummary');
    declinedSummary = document.getElementById('declinedSummary');

    // Initialize theme
    initializeTheme();

    // CRITICAL SECURITY: Immediate authentication check - no delays or UI exposure
    console.log('[AUTH SECURITY] Starting immediate authentication verification...');
    
    const authLoadingScreen = document.getElementById('authLoadingScreen');
    const appContent = document.getElementById('appContent');
    const authLoadingRedirect = document.getElementById('authLoadingRedirect');
    
    function showAuthenticatedContent() {
        console.log('[AUTH SECURITY] User authenticated - showing application content');
        if (authLoadingScreen) authLoadingScreen.style.display = 'none';
        if (appContent) appContent.style.display = 'block';
        
        // Initialize the authenticated app
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            mainContent.style.display = 'block';
        }
        initializeApp();
    }
    
    function showLoginRedirect() {
        console.log('[AUTH SECURITY] Authentication failed - showing login redirect');
        if (authLoadingScreen) {
            const spinner = authLoadingScreen.querySelector('.auth-loading-spinner');
            const message = authLoadingScreen.querySelector('.auth-loading-message');
            if (spinner) spinner.style.display = 'none';
            if (message) message.textContent = 'Authentication required';
            if (authLoadingRedirect) authLoadingRedirect.style.display = 'block';
        }
        
        // Auto-redirect after 3 seconds
        setTimeout(() => {
            console.log('[AUTH SECURITY] Auto-redirecting to login page');
            window.location.href = 'login.html';
        }, 3000);
    }
    
    // Immediate authentication check - no UI exposure
    const token = getAuthToken();
    console.log('[AUTH SECURITY] Token check result:', !!token);
    
    if (!token) {
        console.log('[AUTH SECURITY] No valid token - initiating secure redirect');
        showLoginRedirect();
        return; // Stop execution - don't initialize any app features
    }
    
    // Token exists - verify it's valid before showing content
    console.log('[AUTH SECURITY] Token found - verifying with server...');
    
    // For now, trust the token if it exists (can be enhanced with server verification)
    // TODO: Add server-side token verification for enhanced security
    try {
        // Basic token validation
        const payload = JSON.parse(atob(token.split('.')[1]));
        if (payload.exp && payload.exp * 1000 < Date.now()) {
            throw new Error('Token expired');
        }
        console.log('[AUTH SECURITY] Token validation successful');
        showAuthenticatedContent();
    } catch (error) {
        console.error('[AUTH SECURITY] Token validation failed:', error);
        localStorage.removeItem('authToken');
        showLoginRedirect();
        return;
    }

    // Initialize change password button visibility
    updateChangePasswordBtnVisibility();

    // Initialize event listeners
    initializeEventListeners();
});

function initializeEventListeners() {
    // Theme toggle
    if (themeToggle) themeToggle.addEventListener('click', toggleTheme);

    // Auth form submission
    if (authForm) authForm.addEventListener('submit', handleAuthSubmit);

    // Switch auth mode
    if (switchAuthMode) switchAuthMode.addEventListener('click', () => setAuthMode(!isLoginMode));

    // Close auth modal on overlay click
    if (authModalOverlay) {
        authModalOverlay.addEventListener('click', (e) => {
            if (e.target === authModalOverlay) {
                hideAuthModal();
            }
        });
    }
    
    // Prevent modal from closing when clicking inside the modal
    if (authModal) {
        authModal.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }

    // Logout button
    if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);

    // Change password button
    const changePasswordBtn = document.getElementById('changePasswordBtn');
    if (changePasswordBtn) {
        changePasswordBtn.addEventListener('click', function() {
            window.location.href = 'update_password.html';
        });
    }

    // Auth login redirect button
    const authLoginRedirectBtn = document.getElementById('authLoginRedirectBtn');
    if (authLoginRedirectBtn) {
        authLoginRedirectBtn.addEventListener('click', function() {
            window.location.href = 'login.html';
        });
    }

    // Search input
    if (searchInput) {
        searchInput.addEventListener('input', debounce(() => {
            filterAndSortData();
        }, 300));
    }

    // Status filter buttons
    if (statusFilterButtonsContainer) {
        statusFilterButtonsContainer.addEventListener('click', function(e) {
            if (e.target.matches('button.filter-button')) {
                const clickedButton = e.target;
                const filterValue = clickedButton.dataset.filterValue;
                
                // Handle "All" button - clear all other selections
                if (filterValue === 'all') {
                    statusFilterButtonsContainer.querySelectorAll('.filter-button').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    clickedButton.classList.add('active');
                } else {
                    // Handle specific status filters - toggle behavior
                    const allButton = statusFilterButtonsContainer.querySelector('.filter-button[data-filter-value="all"]');
                    
                    // If "All" is currently active, remove it first
                    if (allButton && allButton.classList.contains('active')) {
                        allButton.classList.remove('active');
                    }
                    
                    // Toggle the clicked button
                    clickedButton.classList.toggle('active');
                    
                    // If no buttons are active, activate "All"
                    const activeButtons = statusFilterButtonsContainer.querySelectorAll('.filter-button.active');
                    if (activeButtons.length === 0 && allButton) {
                        allButton.classList.add('active');
                    }
                }
                
                filterAndSortData();
            }
        });
    }

    // Account Manager, PIC, and Solutions filters
    if (accountMgrFilterDropdown) {
        accountMgrFilterDropdown.addEventListener('change', function() {
            filterAndSortData();
            // Dashboard cards UPDATE when account manager filter changes
            const filteredData = getCurrentFilteredData();
            updateSummaryCounters(filteredData);
        });
    }
    if (picFilterDropdown) picFilterDropdown.addEventListener('change', filterAndSortData);
    if (solutionsFilterDropdown) {
        solutionsFilterDropdown.addEventListener('change', function() {
            filterAndSortData();
            // Dashboard cards UPDATE when solutions filter changes
            const filteredData = getCurrentFilteredData();
            updateSummaryCounters(filteredData);
        });
    }

    // Create opportunity button
    if (createOpportunityButton) {
        createOpportunityButton.addEventListener('click', showCreateOpportunityModal);
    }

    // Export to Excel button
    if (exportExcelButton) {
        exportExcelButton.addEventListener('click', function() {
            const wb = XLSX.utils.table_to_book(opportunitiesTable, {sheet: "Opportunities"});
            XLSX.writeFile(wb, "opportunities.xlsx");
        });
    }

    // Toggle columns button
    if (toggleColumnsButton) {
        toggleColumnsButton.addEventListener('click', () => {
            columnToggleContainer.classList.toggle('hidden');
        });
    }

    // Dashboard toggle buttons for weekly/monthly comparison
    const weeklyToggle = document.getElementById('weeklyToggle');
    const monthlyToggle = document.getElementById('monthlyToggle');
    const noCompareToggle = document.getElementById('noCompareToggle');
    const saveSnapshotBtn = document.getElementById('saveSnapshotBtn');

    if (weeklyToggle) {
        weeklyToggle.addEventListener('click', () => setComparisonMode('weekly'));
    }
    if (monthlyToggle) {
        monthlyToggle.addEventListener('click', () => setComparisonMode('monthly'));
    }
    if (noCompareToggle) {
        noCompareToggle.addEventListener('click', () => setComparisonMode('none'));
    }
    if (saveSnapshotBtn) {
        saveSnapshotBtn.addEventListener('click', saveManualSnapshot);
    }

    // Storage event listener (for multi-tab support)
    window.addEventListener('storage', function(e) {
        if (e.key === 'authToken') {
            if (!e.newValue) {
                showMainContent(false);
                setAuthMode(true);
                showAuthModal();
            } else {
                showMainContent(true);
                hideAuthModal();
            }
            // Update change password button visibility when auth token changes
            updateChangePasswordBtnVisibility();
        }
    });

    // Edit modal events
    document.getElementById('editRowModalCloseX').addEventListener('click', hideEditRowModal);
    document.getElementById('closeEditRowModalButton').addEventListener('click', hideEditRowModal);
    document.getElementById('editRowForm').addEventListener('submit', handleEditFormSubmit);

    // Revision history modal events
    document.getElementById('closeRevisionHistoryButton').addEventListener('click', hideRevisionHistoryModal);
    document.getElementById('closeRevisionHistoryModalX').addEventListener('click', hideRevisionHistoryModal);
    
    // Handle click outside revision history modal to close
    document.getElementById('revisionHistoryModalOverlay').addEventListener('click', function(e) {
        if (e.target === this) {
            hideRevisionHistoryModal();
        }
    });

    // Handle ESC key for modals
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            hideEditRowModal();
            hideRevisionHistoryModal();
        }
    });

    // Handle click outside modal for edit modal
    document.getElementById('editRowModalOverlay').addEventListener('click', function(e) {
        if (e.target === this) {
            hideEditRowModal();
        }
    });

    // Create Opportunity modal events
    var createOpportunityButton = document.getElementById('createOpportunityButton');
    var createOpportunityModal = document.getElementById('createOpportunityModal');
    var createOpportunityModalOverlay = document.getElementById('createOpportunityModalOverlay');
    var closeCreateOpportunityModalButton = document.getElementById('closeCreateOpportunityModalButton');
    var createOpportunityModalCloseX = document.getElementById('createOpportunityModalCloseX');
    var createOpportunityForm = document.getElementById('createOpportunityForm');

    if (createOpportunityButton && createOpportunityModal && createOpportunityModalOverlay) {
        createOpportunityButton.addEventListener('click', function() {
            // Call our function to dynamically create the form with proper dropdowns
            showCreateOpportunityModal();
        });
    }
    function closeCreateModal() {
        createOpportunityModal.classList.add('hidden');
        createOpportunityModalOverlay.classList.add('hidden');
        // Clear form content completely, don't just reset values
        if (createOpportunityForm) createOpportunityForm.innerHTML = '';
    }
    if (closeCreateOpportunityModalButton) {
        closeCreateOpportunityModalButton.addEventListener('click', closeCreateModal);
    }
    if (createOpportunityModalCloseX) {
        createOpportunityModalCloseX.addEventListener('click', closeCreateModal);
    }
    if (createOpportunityModalOverlay) {
        createOpportunityModalOverlay.addEventListener('click', function(e) {
            if (e.target === createOpportunityModalOverlay) closeCreateModal();
        });
    }
    
    // Optionally: ESC key closes modal
    document.addEventListener('keydown', function(e) {
        if (!createOpportunityModal.classList.contains('hidden') && e.key === 'Escape') {
            closeCreateModal();
        }
    });
}

async function handleAuthSubmit(e) {
    e.preventDefault();
    authError.style.display = 'none';
    authSuccess.style.display = 'none';
    authSubmitBtn.disabled = true;
    
    const email = authEmail.value.trim();
    const password = authPassword.value;
    
    if (!validateEmail(email)) {
        authError.textContent = 'Invalid email format.';
        authError.style.display = 'block';
        authSubmitBtn.disabled = false;
        return;
    }
    
    if (!validatePassword(password)) {
        authError.textContent = 'Password must be 8-100 characters.';
        authError.style.display = 'block';
        authSubmitBtn.disabled = false;
        return;
    }
    
    try {
        const res = await fetch(getApiUrl('/api/login'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Login failed');
        
        localStorage.setItem('authToken', data.token);
        updateUserMgmtNavVisibility();
        updateChangePasswordBtnVisibility();
        showMainContent(true);
        hideAuthModal();
        await initializeApp();
    } catch (err) {
        authError.textContent = err.message;
        authError.style.display = 'block';
    } finally {
        authSubmitBtn.disabled = false;
    }
}

function handleLogout() {
    localStorage.removeItem('authToken');
    window.location.href = 'login.html';
}

// --- Theme Management ---
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme');
    // Default to dark theme if no saved preference
    const theme = savedTheme || 'dark';
    if (savedTheme === null) {
        localStorage.setItem('theme', 'dark');
    }
    
    applyTheme(theme);
    
    const logo = document.getElementById('cmrpLogo');
    if (logo) {
        logo.src = 'Logo/CMRP Logo Light.svg';
    }
    
    console.log(`Theme initialized: ${theme}`);
}

function applyTheme(theme) {
    const isDark = theme === 'dark';
    htmlElement.classList.toggle('dark', isDark);
    
    // Update theme toggle button icon - always show sun icon
    const themeToggle = document.getElementById('themeToggle');
    const icon = themeToggle?.querySelector('.material-icons');
    if (icon) {
        icon.textContent = 'wb_sunny';
    }
    
    // Update logo for theme - always use light logo (header is always dark)
    const logo = document.getElementById('cmrpLogo');
    if (logo) {
        logo.src = 'Logo/CMRP Logo Light.svg';
    }
    
    // Force refresh of table styling if table exists
    const table = document.getElementById('opportunitiesTable');
    if (table) {
        // Trigger a repaint to ensure CSS variables are applied
        table.style.display = 'none';
        table.offsetHeight; // Force reflow
        table.style.display = 'table';
    }
    
    console.log(`Theme applied: ${theme}`);
}

function toggleTheme() {
    const currentTheme = htmlElement.classList.contains('dark') ? 'dark' : 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    applyTheme(newTheme);
    localStorage.setItem('theme', newTheme);
}

// --- Auth Modal Logic ---
function showAuthModal() {
    authModalOverlay.style.display = 'block';
    authModal.style.display = 'block';
}

function hideAuthModal() {
    try {
        if (authModalOverlay) authModalOverlay.style.display = 'none';
        if (authModal) authModal.style.display = 'none';
        if (authError) authError.style.display = 'none';
        if (authSuccess) authSuccess.style.display = 'none';
        if (authForm) authForm.reset();
    } catch (error) {
        console.error('Error hiding auth modal:', error);
    }
}

function setAuthMode(login) {
    isLoginMode = login;
    document.getElementById('authModalTitle').textContent = login ? 'Login' : 'Register';
    authSubmitBtn.textContent = login ? 'Login' : 'Register';
    document.getElementById('registerFields').style.display = login ? 'none' : 'block';
    switchAuthMode.textContent = login ? "Don't have an account? Register" : "Already have an account? Login";
    authError.style.display = 'none';
    authSuccess.style.display = 'none';
    authForm.reset();
}

function hideRemarksModal() {
    const overlay = document.getElementById('remarksModalOverlay');
    const modal = document.getElementById('remarksModal');
    
    if (overlay) {
        overlay.classList.add('hidden');
        // Remove any event listeners that might be attached
        overlay.replaceWith(overlay.cloneNode(true));
    }
    if (modal) {
        modal.classList.add('hidden');
    }
}

function hideRevisionHistoryModal() {
    const overlay = document.getElementById('revisionHistoryModalOverlay');
    if (overlay) overlay.classList.add('hidden');
}

function hideEditRowModal() {
    const overlay = document.getElementById('editRowModalOverlay');
    if (overlay) overlay.classList.add('hidden');
}

function showEditRowModal(rowIndex, isDuplicate = false) {
    const overlay = document.getElementById('editRowModalOverlay');
    const modal = document.getElementById('editRowModal');
    const form = document.getElementById('editRowForm');
    
    if (!overlay || !modal || !form) {
        console.error('Edit row modal elements not found');
        return;
    }

    // Update dropdown options before showing the modal
    dropdownOptions = getDropdownOptions(headers, opportunities);

    // Set mode variables
    isCreateMode = isDuplicate;
    currentEditRowIndex = isDuplicate ? -1 : rowIndex;
    
    // Get the current row data
    const rowData = opportunities[rowIndex];
    if (!rowData) {
        console.error('No data found for row index:', rowIndex);
        return;
    }
    
    // Store original values for change detection
    window.originalFormValues = {};
    
    // Clear and populate the form
    form.innerHTML = '';
    
    console.log('[DEBUG] Available headers:', headers);
    console.log('[DEBUG] Creating edit form for row:', rowData);
    
    // Create form fields for each editable column
    const editableFields = [
        'project_name', 'rev', 'client', 'solutions', 'sol_particulars', 'industries', 'ind_particulars',
        'date_received', 'client_deadline', 'decision',
        'account_mgr', 'pic', 'bom', 'status', 'submitted_date',
        'margin', 'final_amt', 'opp_status', 'date_awarded_lost',
        'a', 'c', 'r', 'u', 'd',
        'remarks_comments', 'forecast_date'
    ];
    
    editableFields.forEach(field => {
        const headerExists = headers.includes(field);
        const normalizedField = normalizeField(field);
        const normalizedHeaderExists = headers.some(h => normalizeField(h) === normalizedField);
        
        console.log(`[DEBUG] Checking field "${field}" (normalized: "${normalizedField}"): headerExists=${headerExists}, normalizedHeaderExists=${normalizedHeaderExists}`);
        
        // Special debug for ACRUD fields
        if (['a', 'c', 'r', 'u', 'd'].includes(field.toLowerCase())) {
            console.log(`[DEBUG] ACRUD field detected: "${field}"`);
        }
        
        // Always create field inputs for all editable fields to match create modal behavior
        const actualHeader = headers.find(h => normalizeField(h) === normalizedField) || field;
        const value = rowData[actualHeader] || '';
        
        console.log(`[DEBUG] Creating form field "${field}" with actualHeader="${actualHeader}" and value="${value}"`);
        
        const formGroup = document.createElement('div');
        formGroup.className = 'form-group';
        
        const label = document.createElement('label');
        label.textContent = actualHeader.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        label.setAttribute('for', field);
        
        let input;
        // Use dropdown if getFieldOptions returns options
        const options = getFieldOptions(field);
        console.log(`[DEBUG] Field "${field}" getFieldOptions returned:`, options);
        if (options && options.length > 0) {
            input = document.createElement('select');
            input.className = 'w-full p-2 border rounded dropdown-field';
            // Clear any existing options first
            input.innerHTML = '';
            options.forEach(option => {
                const optionEl = document.createElement('option');
                optionEl.value = option;
                optionEl.textContent = option;
                if (option === value) {
                    optionEl.selected = true;
                }
                input.appendChild(optionEl);
            });
        } else if (field === 'remarks_comments') {
            input = document.createElement('textarea');
            input.rows = 4;
            input.className = 'w-full p-2 border rounded';
        } else if (field.includes('date') || field === 'client_deadline') {
            input = document.createElement('input');
            input.type = 'date';
            input.className = 'w-full p-2 border rounded';
            if (value) {
                // Format date properly for date inputs
                try {
                    const dateObj = new Date(value);
                    if (!isNaN(dateObj)) {
                        input.value = dateObj.toISOString().split('T')[0];
                    }
                } catch (e) {
                    console.error(`Error formatting date for field ${field}:`, e);
                }
            }
        } else if (field === 'margin') {
            input = document.createElement('input');
            input.type = 'number';
            input.step = '0.01';
            input.min = '0';
            input.max = '100';
            input.className = 'w-full p-2 border rounded';
            // For margin field, strip % sign and convert to number
            if (value) {
                const numericValue = parseFloat(value.toString().replace('%', ''));
                if (!isNaN(numericValue)) {
                    input.value = numericValue;
                }
            }
        } else if (field === 'final_amount') {
            input = document.createElement('input');
            input.type = 'number';
            input.step = '0.01';
            input.className = 'w-full p-2 border rounded';
            // For final_amount, strip currency symbols and parse number
            if (value) {
                const numericValue = parseCurrency(value);
                if (!isNaN(numericValue)) {
                    input.value = numericValue;
                }
            }
        } else {
            input = document.createElement('input');
            input.type = 'text';
            input.className = 'w-full p-2 border rounded';
        }
        
        input.id = field;
        input.name = field;
        if (input.type !== 'date' && field !== 'margin' && field !== 'final_amount') {
            input.value = value;
        }
            
        // Store original value for change detection
        window.originalFormValues[field] = value;
        
        formGroup.appendChild(label);
        formGroup.appendChild(input);
        form.appendChild(formGroup);
    });
    
    // Update modal title
    const modalTitle = modal.querySelector('h2');
    if (modalTitle) {
        modalTitle.textContent = isDuplicate ? 'Duplicate Opportunity' : 'Edit Opportunity';
    }
    
    // Show the modal
    overlay.classList.remove('hidden');
}

function showCreateOpportunityModal() {
    const overlay = document.getElementById('createOpportunityModalOverlay');
    const modal = document.getElementById('createOpportunityModal');
    const form = document.getElementById('createOpportunityForm');
    if (!overlay || !modal || !form) return;
    
    // Update dropdown options before showing the modal
    dropdownOptions = getDropdownOptions(headers, opportunities);

    // Use the same editable fields as edit modal
    const editableFields = [
        'project_name', 'rev', 'client', 'solutions', 'sol_particulars', 'industries', 'ind_particulars',
        'date_received', 'client_deadline', 'decision',
        'account_mgr', 'pic', 'bom', 'status', 'submitted_date',
        'margin', 'final_amt', 'opp_status', 'date_awarded_lost',
        'a', 'c', 'r', 'u', 'd',
        'remarks_comments', 'forecast_date'
    ];
    form.innerHTML = '';
    editableFields.forEach(field => {
        const formGroup = document.createElement('div');
        formGroup.className = 'form-group mb-4';
        const label = document.createElement('label');
        label.textContent = field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        label.setAttribute('for', field);
        let input;
        // Use dropdown if getFieldOptions returns options
        const options = getFieldOptions(field);
        console.log(`[DEBUG] Create Modal - Field "${field}" getFieldOptions returned:`, options);
        if (options && options.length > 0) {
            input = document.createElement('select');
            input.className = 'w-full p-2 border rounded dropdown-field';
            // Clear any existing options first
            input.innerHTML = '';
            options.forEach(option => {
                const optionEl = document.createElement('option');
                optionEl.value = option;
                optionEl.textContent = option;
                input.appendChild(optionEl);
            });
        } else if (field === 'remarks_comments') {
            input = document.createElement('textarea');
            input.rows = 4;
            input.className = 'w-full p-2 border rounded';
        } else if (field.includes('date') || field === 'client_deadline') {
            input = document.createElement('input');
            input.type = 'date';
            input.className = 'w-full p-2 border rounded';
        } else if (field === 'margin' || field === 'final_amount') {
            input = document.createElement('input');
            input.type = 'number';
            input.step = '0.01';
            input.className = 'w-full p-2 border rounded';
        } else {
            input = document.createElement('input');
            input.type = 'text';
            input.className = 'w-full p-2 border rounded';
        }
        input.id = field;
        input.name = field;
        formGroup.appendChild(label);
        formGroup.appendChild(input);
        form.appendChild(formGroup);
    });
    
    // Add submit event listener for the dynamically created form
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('[DEBUG] Create form submit triggered');
        
        // Set create mode variables
        isCreateMode = true;
        currentEditRowIndex = -1;
        
        // Use the same handler as edit form
        handleEditFormSubmit(e);
    });
    
    overlay.classList.remove('hidden');
    modal.classList.remove('hidden');
}

// Helper function to get field options for dropdowns
function getFieldOptions(field) {
    switch (field) {
        case 'decision':
            return ['', 'GO', 'DECLINE', 'Pending'];
        case 'status':
            return ['', 'On-Going', 'For Revision', 'For Approval', 'Submitted', 'No Decision Yet', 'Not Yet Started'];
        case 'opp_status':
            return ['', 'OP100', 'LOST', 'OP90', 'OP60', 'OP30'];
        case 'a':
            return ['', '10-Existing', '10-Strategic', '5-New Account, No Champion', '2-Existing account with No Orders'];
        case 'c':
            return ['', '10 -Existing Solution', '8 -Need to Customize', '5 -Need External Resource'];
        case 'r':
            return ['', '10 -Focus Business', '10 -Core Business', '8 -Strategic Business', '7 -Core + Peripheral', '5 -Peripheral Scope', '2 -Non Core for Subcon'];
        case 'u':
            return ['', '10 -Reasonable Time', '7 -Urgent', '5 -Budgetary'];
        case 'd':
            return ['', '10 -Complete', '5 -Limited', '2 -No Data'];
        case 'solutions':
            return ['', 'Automation', 'Electrification', 'Digitalization'];
        case 'sol_particulars':
            return ['', 'PLC / SCADA', 'CCTV', 'IT', 'ACS', 'INSTRUMENTATION', 'ELECTRICAL', 'FDAS', 'BMS', 'EE & AUX', 'PABGM', 'SOLAR', 'SCS', 'MECHANICAL', 'AUXILIARY', 'MEPFS', 'CIVIL'];
        case 'industries':
            return ['', 'Manufacturing', 'Buildings', 'Power'];
        case 'ind_particulars':
            return ['', 'F&B', 'CONSTRUCTION', 'MANUFACTURING', 'POWER PLANT', 'CEMENT', 'SEMICON', 'OIL & GAS', 'OTHERS', 'UTILITIES', 'COLD STORAGE', 'PHARMA'];
        case 'account_mgr':
            // Get values from dropdownOptions if available, otherwise return empty array with blank option
            return dropdownOptions.accountmgr ? ['', ...dropdownOptions.accountmgr] : [''];
        case 'pic':
            // Get values from dropdownOptions if available, otherwise return empty array with blank option
            return dropdownOptions.pic ? ['', ...dropdownOptions.pic] : [''];
        case 'bom':
            // Get values from dropdownOptions if available, otherwise return empty array with blank option
            return dropdownOptions.bom ? ['', ...dropdownOptions.bom] : [''];
        default:
            return [];
    }
}

function showRevisionHistoryModal(uid) {
    const overlay = document.getElementById('revisionHistoryModalOverlay');
    const modal = document.getElementById('revisionHistoryModal');
    const tableBody = document.querySelector('#revisionHistoryContent tbody');
    
    if (!overlay || !modal || !tableBody) {
        console.error('Revision history modal elements not found');
        return;
    }
    
    // Show loading state
    tableBody.innerHTML = '<tr><td colspan="6" class="text-center p-4 loading-text">Loading revision history...</td></tr>';
    
    // Show the modal
    overlay.classList.remove('hidden');
    
    // Load and display revision history
    loadRevisionHistory(uid, tableBody);
}

async function loadRevisionHistory(uid, tableBody) {
    try {
        const token = getAuthToken();
        if (!token) {
            throw new Error('No authentication token found. Please log in again.');
        }

        const response = await fetch(getApiUrl(`/api/opportunities/${encodeURIComponent(uid)}/revisions`), {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to fetch revision history');
        }

        const revisions = await response.json();
        
        if (revisions.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center p-4">No revision history found for this opportunity.</td></tr>';
            return;
        }

        // Populate the table with revision data
        tableBody.innerHTML = '';
        revisions.forEach(revision => {
            const row = document.createElement('tr');
            
            // Revision number
            const revCell = document.createElement('td');
            revCell.className = 'px-3 py-2 border-b text-center';
            revCell.textContent = revision.revision_number || 'N/A';
            row.appendChild(revCell);
            
            // Changed by
            const changedByCell = document.createElement('td');
            changedByCell.className = 'px-3 py-2 border-b';
            changedByCell.textContent = revision.changed_by || 'N/A';
            row.appendChild(changedByCell);
            
            // Changed at
            const changedAtCell = document.createElement('td');
            changedAtCell.className = 'px-3 py-2 border-b';
            const date = new Date(revision.changed_at);
            changedAtCell.textContent = formatDateWithDay(revision.changed_at);
            row.appendChild(changedAtCell);
            
            // Parse changed fields to show individual field changes
            let changedFields = {};
            
            try {
                // Handle case where changed_fields might already be an object (depending on DB driver)
                if (typeof revision.changed_fields === 'string') {
                    changedFields = JSON.parse(revision.changed_fields || '{}');
                } else if (typeof revision.changed_fields === 'object' && revision.changed_fields !== null) {
                    changedFields = revision.changed_fields;
                } else {
                    changedFields = {};
                }
            } catch (e) {
                console.warn('Failed to parse changed_fields:', e);
                changedFields = {};
            }
            
            // If we have field changes, create a row for each
            const fieldNames = Object.keys(changedFields);
            
            if (fieldNames.length === 0) {
                // No specific field changes, show general info
                const fieldCell = document.createElement('td');
                fieldCell.className = 'px-3 py-2 border-b text-gray-500';
                fieldCell.textContent = revision.revision_number === 1 ? 'Initial revision' : 'General update';
                row.appendChild(fieldCell);
                
                const oldValueCell = document.createElement('td');
                oldValueCell.className = 'px-3 py-2 border-b text-gray-400';
                oldValueCell.textContent = '-';
                row.appendChild(oldValueCell);
                
                const newValueCell = document.createElement('td');
                newValueCell.className = 'px-3 py-2 border-b text-gray-400';
                newValueCell.textContent = '-';
                row.appendChild(newValueCell);
                
                tableBody.appendChild(row);
            } else {
                // Show first field in this row, then create additional rows for other fields
                let isFirstField = true;
                fieldNames.forEach(fieldName => {
                    const currentRow = isFirstField ? row : document.createElement('tr');
                    
                    if (!isFirstField) {
                        // For additional fields, add empty cells for revision, changed_by, changed_at
                        ['', '', ''].forEach(() => {
                            const emptyCell = document.createElement('td');
                            emptyCell.className = 'px-3 py-2 border-b text-gray-400';
                            emptyCell.textContent = '↳';
                            currentRow.appendChild(emptyCell);
                        });
                    }
                    
                    // Field name
                    const fieldCell = document.createElement('td');
                    fieldCell.className = 'px-3 py-2 border-b';
                    fieldCell.textContent = fieldName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                    currentRow.appendChild(fieldCell);
                    
                    const changeInfo = changedFields[fieldName];
                    let oldValue = '-';
                    let newValue = '-';
                    
                    // Handle enhanced field tracking format with old/new values
                    if (changeInfo && typeof changeInfo === 'object' && changeInfo.hasOwnProperty('old') && changeInfo.hasOwnProperty('new')) {
                        oldValue = changeInfo.old !== null && changeInfo.old !== undefined ? changeInfo.old : '(empty)';
                        newValue = changeInfo.new !== null && changeInfo.new !== undefined ? changeInfo.new : '(empty)';
                    } else {
                        // Fallback for legacy format where changeInfo is just the new value
                        oldValue = '(unknown)';
                        newValue = changeInfo !== null && changeInfo !== undefined ? changeInfo : '(empty)';
                    }
                    
                    // Apply formatting to old and new values using the same logic as the main table
                    if (oldValue !== '(empty)' && oldValue !== '(unknown)' && oldValue !== '-') {
                        oldValue = formatCellValue(oldValue, fieldName);
                    }
                    if (newValue !== '(empty)' && newValue !== '-') {
                        newValue = formatCellValue(newValue, fieldName);
                    }
                    
                    // Old value
                    const oldValueCell = document.createElement('td');
                    oldValueCell.className = 'px-3 py-2 border-b';
                    oldValueCell.textContent = oldValue;
                    currentRow.appendChild(oldValueCell);
                    
                    // New value
                    const newValueCell = document.createElement('td');
                    newValueCell.className = 'px-3 py-2 border-b';
                    newValueCell.textContent = newValue;
                    currentRow.appendChild(newValueCell);
                    
                    tableBody.appendChild(currentRow);
                    isFirstField = false;
                });
            }
        });

    } catch (error) {
        console.error('Error loading revision history:', error);
        tableBody.innerHTML = `<tr><td colspan="6" class="text-center p-4 text-red-600">Error loading revision history: ${error.message}</td></tr>`;
    }
}

// --- Helper Functions ---
function isAuthenticated() {
    return !!localStorage.getItem('authToken');
}

function showMainContent(show) {
    document.querySelector('.main-content').style.display = show ? 'block' : 'none';
    authModalOverlay.style.display = show ? 'none' : 'block';
    authModal.style.display = show ? 'none' : 'block';
}

// --- User Management Nav Visibility ---
function updateUserMgmtNavVisibility() {
    const token = localStorage.getItem('authToken');
    const userRole = token ? JSON.parse(atob(token.split('.')[1])).role : null;
    const userMgmtNav = document.getElementById('userMgmtNav');
    if (userMgmtNav) {
        userMgmtNav.style.display = userRole === 'admin' ? '' : 'none';
    }
}

// --- Change Password Button Visibility ---
function updateChangePasswordBtnVisibility() {
    const changePasswordBtn = document.getElementById('changePasswordBtn');
    if (!changePasswordBtn) return;
    
    const token = localStorage.getItem('authToken');
    if (!token) {
        changePasswordBtn.style.display = 'none';
    } else {
        changePasswordBtn.style.display = '';
    }
}

// --- Table Operations ---
function buildHeaderMap(headersToMap) { // Map normalized header to actual header
    headerIndices = {};
    headersToMap.forEach((header, index) => {
        const norm = normalizeField(header);
        headerIndices[norm] = index;
        if (norm.includes('particulars')) {
            particularsIndices.push(index);
        }
    });
}

function getDropdownOptions(headersToUse, data) {
    const options = {};
    DROPDOWN_FIELDS.forEach(field => {
        const normField = normalizeField(field);
        let values = new Set();

        // Find the index of this field in the headers array
        let fieldIndex = -1;
        for (let i = 0; i < headersToUse.length; i++) {
            if (normalizeField(headersToUse[i]) === normField) {
                fieldIndex = i;
                break;
            }
        }

        // If field found in headers, collect unique values
        if (fieldIndex !== -1) {
            data.forEach(row => {
                const value = row[headersToUse[fieldIndex]];
                if (value) values.add(value);
            });
        }

        // Special handling for Account Manager, PIC and BOM
        if (normField === 'accountmgr') {
            for (let i = 0; i < headersToUse.length; i++) {
                if (normalizeField(headersToUse[i]) === 'accountmgr') {
                    data.forEach(row => {
                        const value = row[headersToUse[i]];
                        if (value) values.add(value);
                    });
                }
            }
        } 
        else if (normField === 'pic') {
            for (let i = 0; i < headersToUse.length; i++) {
                if (normalizeField(headersToUse[i]) === 'pic') {
                    data.forEach(row => {
                        const value = row[headersToUse[i]];
                        if (value) values.add(value);
                    });
                }
            }
        }
        else if (normField === 'bom') {
            for (let i = 0; i < headersToUse.length; i++) {
                if (normalizeField(headersToUse[i]) === 'bom') {
                    data.forEach(row => {
                        const value = row[headersToUse[i]];
                        if (value) values.add(value);
                    });
                }
            }
        }

        options[normField] = Array.from(values).sort();
    });

    return options;
}

// This function has been replaced by initializeTableHeader() which includes Actions column

function populateTableBody(data) {
    if (!data || !data.length) {
        tableBody.innerHTML = '<tr><td colspan="100%" class="text-center p-4">No data available</td></tr>';
        return;
    }
    tableBody.innerHTML = '';
    // Find first visible column index
    const firstVisibleIndex = headers.findIndex((h, i) => columnVisibility[h]);
    data.forEach((row, rowIndex) => {
        const tr = document.createElement('tr');
        // Store the original index from opportunities array
        const originalIndex = opportunities.findIndex(opp => opp.uid === row.uid);
        tr.dataset.originalIndex = originalIndex;

        // Add status-based classes
        const status = row.opp_status?.toLowerCase();
        if (status === 'op100') {
            tr.classList.add('bg-op100');
        } else if (status === 'lost') {
            tr.classList.add('bg-lost');
        } else if (row.decision?.toLowerCase() === 'decline') {
            tr.classList.add('bg-declined');
        }

        let visibleColumnIndex = 0; // Track visible column position
        
        headers.forEach((header, index) => {
            // Check if columnVisibility is properly configured - if not, make all columns visible
            if (!columnVisibility) {
                columnVisibility = {};
                headers.forEach(h => columnVisibility[h] = true);
            }
            
            if (!columnVisibility[header]) return; // Skip hidden columns
            const td = document.createElement('td');
            td.innerHTML = formatCellValue(row[header], header);
            
            // Set the appropriate width based on column type
            const columnWidth = getDefaultColumnWidth(header);
            td.style.minWidth = columnWidth;
            td.style.width = columnWidth;
            
            // Add appropriate classes
            if (rightAlignColumns.includes(header.toLowerCase())) {
                td.classList.add('numeric-column');
                td.style.textAlign = 'right';
            }
            
            // Check if this is the project name column (with various possible field names)
            const normalizedHeader = (header || '').toLowerCase().replace(/[^a-z0-9]/g, '');
            const isProjectNameColumn = normalizedHeader === 'projectname' || header.toLowerCase() === 'project_name';
            const isFirstVisibleColumn = visibleColumnIndex === 0;
            
            if (isProjectNameColumn || isFirstVisibleColumn) {
                td.classList.add('project-name-cell');
                // Make project name column sticky - using class for styling
                td.classList.add('sticky-col');
                // Forcefully apply styles for text wrapping
                td.style.whiteSpace = 'normal';
                td.style.wordBreak = 'break-word'; 
                td.style.wordWrap = 'break-word';
                td.style.overflow = 'visible';
                td.style.textOverflow = 'unset';
                td.style.padding = '12px';
                
                // Set background color based on row status
                // Using custom data attribute for status to use in CSS
                if (row.opp_status?.toLowerCase() === 'op100') {
                    td.dataset.rowStatus = 'op100';
                } else if (status === 'lost') {
                    td.dataset.rowStatus = 'lost';
                } else if (row.decision?.toLowerCase() === 'decline') {
                    td.dataset.rowStatus = 'declined';
                }
            }
            
            // Check if this is the remarks_comments column
            const normalizedHeaderForRemarks = (header || '').toLowerCase().replace(/[^a-z0-9]/g, '');
            if (normalizedHeaderForRemarks === 'remarkscomments' || header.toLowerCase().includes('remarks')) {
                td.classList.add('remarks-cell');
            }
            
            // Make cell editable
            makeEditable(td, row, header, originalIndex);
            
            tr.appendChild(td);
            visibleColumnIndex++; // Increment visible column counter
        });

        // Add action buttons
        const actionsTd = document.createElement('td');
        actionsTd.className = 'center-align-cell';
        
        const btnContainer = document.createElement('div');
        btnContainer.className = 'flex justify-center items-center gap-2';

        // Edit button
        const editBtn = document.createElement('button');
        editBtn.innerHTML = '<span class="material-icons" style="font-size:1em;vertical-align:middle;">edit</span>';
        editBtn.className = 'action-button px-2 py-1 rounded text-xs';
        editBtn.title = 'Edit Opportunity';
        editBtn.onclick = () => showEditRowModal(originalIndex);
        btnContainer.appendChild(editBtn);

        // Duplicate button
        const duplicateBtn = document.createElement('button');
        duplicateBtn.innerHTML = '<span class="material-icons" style="font-size:1em;vertical-align:middle;">content_copy</span>';
        duplicateBtn.className = 'theme-button px-2 py-1 rounded text-xs';
        duplicateBtn.title = 'Duplicate Opportunity';
        duplicateBtn.onclick = () => showEditRowModal(originalIndex, true);
        btnContainer.appendChild(duplicateBtn);

        // Delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.innerHTML = '<span class="material-icons" style="font-size:1em;vertical-align:middle;">delete</span>';
        deleteBtn.className = 'theme-button px-2 py-1 rounded text-xs';
        deleteBtn.title = 'Delete Opportunity';
        deleteBtn.onclick = async () => {
            if (confirm('Are you sure you want to delete this opportunity?')) {
                try {
                    const token = getAuthToken();
                    const response = await fetch(getApiUrl(`/api/opportunities/${encodeURIComponent(row.uid)}`), {
                        method: 'DELETE',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    if (!response.ok) {
                        const err = await response.json();
                        throw new Error(err.error || response.statusText);
                    }
                    // Remove from local data and re-render
                    const idx = opportunities.findIndex(opp => opp.uid === row.uid);
                    if (idx !== -1) opportunities.splice(idx, 1);
                    filterAndSortData();
                    updateRowCount();
                    // Dashboard cards are refreshed via loadDashboardData()
                    const filteredData = getCurrentFilteredData();
                    loadDashboardData(filteredData);
                    alert('Opportunity deleted successfully.');
                } catch (err) {
                    alert('Failed to delete: ' + err.message);
                }
            }
        };
        btnContainer.appendChild(deleteBtn);

        // History button
        const historyBtn = document.createElement('button');
        historyBtn.innerHTML = '<span class="material-icons" style="font-size:1em;vertical-align:middle;">history</span>';
        historyBtn.className = 'theme-button px-2 py-1 rounded text-xs';
        historyBtn.title = 'View Revision History';
        historyBtn.onclick = () => showRevisionHistoryModal(row.uid);
        btnContainer.appendChild(historyBtn);

        actionsTd.appendChild(btnContainer);
        tr.appendChild(actionsTd);
        tableBody.appendChild(tr);
    });
}

function getCellClass(header) {
    const normHeader = normalizeField(header);
    if (rightAlignColumns.includes(normHeader)) return 'text-right';
    return '';
}

function handleSortClick(columnIndex) {
    if (currentSortColumnIndex === columnIndex) {
        // Toggle direction if same column
        currentSortDirection = currentSortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        // New column, default to ascending
        currentSortColumnIndex = columnIndex;
        currentSortDirection = 'asc';
    }
    
    filterAndSortData();
    updateSortIndicators();
}

function updateSortIndicators() {
    const headers = tableHead.querySelectorAll('th');
    headers.forEach((th, index) => {
        th.classList.remove('sort-asc', 'sort-desc');
        if (index === currentSortColumnIndex) {
            th.classList.add(`sort-${currentSortDirection}`);
        }
    });
}

function filterAndSortData() {
    const filters = getActiveFilters();
    
    // Filter data
    const filteredData = opportunities.filter(opp => {
        // Search filter
        if (filters.search) {
            const searchStr = filters.search.toLowerCase();
            const matchFound = Object.values(opp).some(value => 
                String(value).toLowerCase().includes(searchStr)
            );
            if (!matchFound) return false;
        }

        // Status filter - now supports multiple selections
        if (filters.status && filters.status.length > 0 && !filters.status.includes('all')) {
            const oppStatus = (opp.opp_status || '').toLowerCase();
            const currentStatus = (opp.status || '').toLowerCase();
            const decision = (opp.decision || '').toLowerCase();
            
            // Check if the opportunity matches any of the selected status filters
            const matchesAnyStatus = filters.status.some(status => {
                const statusLower = status.toLowerCase();
                
                // Map filter button values to actual data values
                switch (statusLower) {
                    case 'op100':
                        return oppStatus === 'op100';
                    case 'op90':
                        return oppStatus === 'op90';
                    case 'op60':
                        return oppStatus === 'op60';
                    case 'op30':
                        return oppStatus === 'op30';
                    case 'submitted':
                        return oppStatus === 'op30' || oppStatus === 'op60';
                    case 'ongoing':
                        return currentStatus === 'on-going';
                    case 'not_yet_started':
                        return currentStatus === 'not yet started';
                    case 'no_decision':
                        return decision !== 'go' && decision !== 'decline';
                    case 'lost':
                        return oppStatus === 'lost' || decision === 'lost';
                    case 'declined':
                        return decision === 'decline';
                    case 'inactive':
                        return oppStatus === 'inactive';
                    default:
                        return false;
                }
            });
            
            if (!matchesAnyStatus) return false;
        }

        // Solutions filter
        if (filters.solutions && filters.solutions !== 'all' && opp.solutions !== filters.solutions) {
            return false;
        }

        // Account Manager filter
        if (filters.accountMgr && filters.accountMgr !== 'all' && opp.account_mgr !== filters.accountMgr) {
            return false;
        }

        // PIC filter
        if (filters.pic && filters.pic !== 'all' && opp.pic !== filters.pic) {
            return false;
        }

        return true;
    });

    // Sort data if sort column is set
    if (currentSortColumnIndex >= 0 && headers[currentSortColumnIndex]) {
        const sortHeader = headers[currentSortColumnIndex];
        filteredData.sort((a, b) => {
            let aVal = a[sortHeader];
            let bVal = b[sortHeader];

            // Handle different types of values
            if (isDateField(sortHeader)) {
                aVal = parseDateString(aVal) || new Date(0);
                bVal = parseDateString(bVal) || new Date(0);
            } else if (isCurrencyField(sortHeader)) {
                aVal = parseFloat(String(aVal).replace(/[^0-9.-]+/g, '') || '0');
                bVal = parseFloat(String(bVal).replace(/[^0-9.-]+/g, '') || '0');
            } else {
                // Convert to lowercase strings for comparison
                aVal = String(aVal || '').toLowerCase();
                bVal = String(bVal || '').toLowerCase();
            }

            // Compare values
            if (aVal < bVal) return currentSortDirection === 'asc' ? -1 : 1;
            if (aVal > bVal) return currentSortDirection === 'asc' ? 1 : -1;
            return 0;
        });
    }

    // Update table body with filtered data
    populateTableBody(filteredData);
    
    // Update row count with filtered data
    updateRowCount(filteredData);
    
    // Note: Dashboard cards are no longer updated here automatically
    // They are only updated when solutions or account manager filters change
}

// Function to get currently filtered data (used for selective dashboard updates)
function getCurrentFilteredData() {
    const filters = getActiveFilters();
    
    // Apply the same filtering logic as filterAndSortData()
    const filteredData = opportunities.filter(opp => {
        // Search filter
        if (filters.search) {
            const searchStr = filters.search.toLowerCase();
            const matchFound = Object.values(opp).some(value => 
                String(value).toLowerCase().includes(searchStr)
            );
            if (!matchFound) return false;
        }

        // Status filter - supports multiple selections
        if (filters.status && filters.status.length > 0 && !filters.status.includes('all')) {
            const oppStatus = (opp.opp_status || '').toLowerCase();
            const currentStatus = (opp.status || '').toLowerCase();
            const decision = (opp.decision || '').toLowerCase();
            
            // Check if the opportunity matches any of the selected status filters
            const matchesAnyStatus = filters.status.some(status => {
                const statusLower = status.toLowerCase();
                
                // Map filter button values to actual data values
                switch (statusLower) {
                    case 'op100':
                        return oppStatus === 'op100';
                    case 'op90':
                        return oppStatus === 'op90';
                    case 'op60':
                        return oppStatus === 'op60';
                    case 'op30':
                        return oppStatus === 'op30';
                    case 'submitted':
                        return oppStatus === 'op30' || oppStatus === 'op60';
                    case 'ongoing':
                        return currentStatus === 'on-going';
                    case 'not_yet_started':
                        return currentStatus === 'not yet started';
                    case 'no_decision':
                        return decision !== 'go' && decision !== 'decline';
                    case 'lost':
                        return oppStatus === 'lost' || decision === 'lost';
                    case 'declined':
                        return decision === 'decline';
                    case 'inactive':
                        return oppStatus === 'inactive';
                    default:
                        return false;
                }
            });
            
            if (!matchesAnyStatus) return false;
        }

        // Solutions filter
        if (filters.solutions && filters.solutions !== 'all' && opp.solutions !== filters.solutions) {
            return false;
        }

        // Account Manager filter
        if (filters.accountMgr && filters.accountMgr !== 'all' && opp.account_mgr !== filters.accountMgr) {
            return false;
        }

        // PIC filter
        if (filters.pic && filters.pic !== 'all' && opp.pic !== filters.pic) {
            return false;
        }

        return true;
    });

    return filteredData;
}

function updateRowCount(filteredData = null) {
    const rowCountElement = document.getElementById('rowCount');
    if (!rowCountElement) {
        console.warn('Row count element not found');
        return;
    }
    
    // If filteredData is provided, use it; otherwise count visible rows in table body
    let actualCount;
    if (filteredData) {
        actualCount = filteredData.length;
    } else {
        const visibleRows = tableBody.querySelectorAll('tr').length;
        // Don't count the "No data available" row
        actualCount = (visibleRows === 1 && tableBody.querySelector('tr td[colspan]')) ? 0 : visibleRows;
    }
    
    // Update the row count element with the count and total
    const totalCount = opportunities.length;
    const activeFilters = getActiveFiltersDescription();
    const filterText = activeFilters ? ` (${activeFilters})` : '';
    rowCountElement.textContent = `Showing ${actualCount} of ${totalCount} opportunities${filterText}`;
    
    // Add debug logging
    console.log(`Row count updated: ${actualCount} of ${totalCount}${filterText}`);
}

function getDefaultColumnWidth(header) {
    // Customize widths for specific columns if needed
    const normHeader = (header || '').toLowerCase();
    if (normHeader.includes('project')) return '220px';
    if (normHeader.includes('remarks')) return '200px';
    if (normHeader.includes('amount') || normHeader.includes('amt')) return '120px';
    if (normHeader.includes('date')) return '110px';
    if (normHeader.includes('status')) return '100px';
    if (normHeader.includes('manager') || normHeader.includes('account_mgr')) return '140px';
    if (normHeader.includes('pic')) return '120px';
    // Default width
    return '120px';
}

// --- Cell Editing Functions ---
function showRemarksModal(currentValue, header, uid, td) {
    const overlay = document.getElementById('remarksModalOverlay');
    const modal = document.getElementById('remarksModal');
    const textarea = document.getElementById('remarksTextarea');
    const closeBtn = modal.querySelector('button[aria-label="Close"]');
    const saveBtn = document.getElementById('saveRemarksButton');
    const cancelBtn = document.getElementById('closeModalButton');

    if (!overlay || !modal || !textarea || !closeBtn || !saveBtn || !cancelBtn) {
        console.error('Remarks modal elements not found');
        return;
    }

    // Store references for cleanup
    let overlayClickHandler, escHandler;

    // Handle close
    function closeModal() {
        overlay.classList.add('hidden');
        modal.classList.add('hidden');
        
        // Clean up event listeners
        if (overlayClickHandler) {
            overlay.removeEventListener('click', overlayClickHandler);
        }
        if (escHandler) {
            document.removeEventListener('keydown', escHandler);
        }
    }

    // Handle save
    async function saveRemarks() {
        const newValue = textarea.value.trim();
        // Only save if value actually changed
        if (newValue === currentValue) {
            closeModal();
            return;
        }
        try {
            await saveEdit(newValue, header, uid);
            // If td is provided, update it immediately
            if (td) {
                td.textContent = newValue;
                td.dataset.fullRemarks = newValue;
            }
            closeModal();
        } catch (error) {
            console.error('Error saving remarks:', error);
            alert('Failed to save remarks: ' + error.message);
        }
    }

    // Clean up any existing event listeners first
    const newCloseBtn = closeBtn.cloneNode(true);
    const newSaveBtn = saveBtn.cloneNode(true);
    const newCancelBtn = cancelBtn.cloneNode(true);
    
    closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
    saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
    cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);

    // Add fresh event listeners
    newCloseBtn.addEventListener('click', closeModal);
    newSaveBtn.addEventListener('click', saveRemarks);
    newCancelBtn.addEventListener('click', closeModal);
    
    // Set up overlay click handler
    overlayClickHandler = (e) => {
        if (e.target === overlay) closeModal();
    };
    overlay.addEventListener('click', overlayClickHandler);

    // Set up ESC key handler
    escHandler = (e) => {
        if (e.key === 'Escape') {
            closeModal();
        }
    };
    document.addEventListener('keydown', escHandler);

    // Set current value and show modal
    textarea.value = currentValue || '';
    overlay.classList.remove('hidden');
    modal.classList.remove('hidden');
    
    // Focus the textarea with a slight delay to ensure modal is visible
    setTimeout(() => {
        textarea.focus();
    }, 100);
}

function makeEditable(td, originalFullRow, header, originalIndex) {
    const normHeader = normalizeField(header);
    // Don't make certain columns editable
    const nonEditableColumns = ['uid', 'encodeddate'];
    if (nonEditableColumns.includes(normHeader)) return;

    td.classList.add('editable-cell');
    td.title = "Double-click to edit";

    td.addEventListener('dblclick', function(e) {
        if (td.querySelector('input, select, textarea')) return; // Already editing

        const currentValue = originalFullRow[header] ?? '';

        // Special handling for remarks_comments
        if (normHeader === 'remarkscomments') {
            showRemarksModal(currentValue, header, originalFullRow.uid, td);
            return;
        }

        // Regular inline editing for other fields
        const input = createEditInput(normHeader, currentValue);

        // --- Fixed: Constrained inline editor styling ---
        input.style.background = getComputedStyle(document.body).getPropertyValue('--bg-modal') || '#fff';
        input.style.color = getComputedStyle(document.body).getPropertyValue('--text-body') || '#222';
        input.style.border = '2px solid #4f46e5';
        input.style.outline = 'none';
        input.style.fontFamily = 'inherit';
        input.style.fontSize = 'inherit';
        input.style.padding = '4px 8px';
        input.style.borderRadius = '4px';
        input.style.boxSizing = 'border-box';
        input.style.zIndex = 1000;
        
        // Set cell to relative positioning to contain the input
        td.style.position = 'relative';
        td.style.overflow = 'visible';
        
        if (input.tagName === 'SELECT') {
            input.style.position = 'relative';
            input.style.width = '100%';
            input.style.minWidth = '120px';
            input.style.maxWidth = '200px';
            input.style.height = 'auto';
        } else {
            // For text inputs, constrain to cell dimensions
            const cellRect = td.getBoundingClientRect();
            input.style.position = 'absolute';
            input.style.left = '0';
            input.style.top = '0';
            input.style.width = `${cellRect.width - 4}px`; // Account for border
            input.style.height = `${cellRect.height - 4}px`; // Account for border
            input.style.minWidth = '80px';
            input.style.maxWidth = '300px';
        }

        // Store original content
        const originalContent = td.innerHTML;
        td.innerHTML = '';
        td.appendChild(input);
        input.focus();

        // If it's a select, open the dropdown immediately (simulate by showing all options)
        if (input.tagName === 'SELECT') {
            const originalSize = input.size;
            input.size = Math.min(input.options.length, 10); // Show up to 10 options
            // Revert to normal dropdown on blur or change
            const revertSize = () => { input.size = originalSize || 0; };
            input.addEventListener('blur', revertSize);
            input.addEventListener('change', revertSize);
        }

        let isProcessingSave = false;
        let saveOnBlur = async () => {
            if (isProcessingSave) return;
            let value = input.value;
            if (input.tagName === 'SELECT') value = input.options[input.selectedIndex].value;
            // Only save if value actually changed
            if (value === currentValue) {
                td.innerHTML = originalContent;
                return;
            }
            isProcessingSave = true;
            await saveEdit(value, header, originalFullRow.uid);
            td.innerHTML = formatCellValue(value, header);
            isProcessingSave = false;
        };

        // Save on Enter, Cancel on ESC
        input.addEventListener('keydown', async function(e) {
            if (e.key === 'Enter' && !isProcessingSave) {
                e.preventDefault();
                await saveOnBlur();
            } else if (e.key === 'Escape') {
                td.innerHTML = originalContent;
            }
        });

        // Save on blur for all input types
        input.addEventListener('blur', function() {
            setTimeout(async () => {
                if (td.contains(input)) {
                    await saveOnBlur();
                }
            }, 100);
        });

        // For select, also save on change
        if (input.tagName === 'SELECT' || input.type === 'date') {
            input.addEventListener('change', async function() {
                await saveOnBlur();
            });
        }
    });
}

function createEditInput(normHeader, currentValue) {
    let input;
    
    if (DROPDOWN_FIELDS_NORM.includes(normHeader)) {
        input = document.createElement('select');
        const options = dropdownOptions[normHeader] || [];
        // Add default empty option for better UX
        const defaultOpt = document.createElement('option');
        defaultOpt.value = '';
        defaultOpt.textContent = '-- Select --';
        input.appendChild(defaultOpt);
        options.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option;
            opt.textContent = option;
            if (option === currentValue) {
                opt.selected = true;
            }
            input.appendChild(opt);
        });
    } else if (normHeader === 'remarkscomments') {
        input = document.createElement('textarea');
        input.value = currentValue || '';
        input.style.minHeight = '200px';
        input.style.width = '100%';
        input.style.padding = '0.5rem';
        input.style.marginTop = '0.5rem';
        input.style.marginBottom = '0.5rem';
        input.style.fontFamily = 'inherit';
        input.style.borderRadius = '4px';
        input.style.border = '1px solid var(--border-color)';
    } else if (isDateField(normHeader)) {
        input = document.createElement('input');
        input.type = 'date';
        input.className = 'w-full p-2 border rounded mt-1 text-sm';
        input.value = currentValue || '';
    } else {
        input = document.createElement('input');
        input.type = 'text';
        input.className = 'w-full p-2 border rounded mt-1 text-sm';
        input.value = currentValue || '';
    }
    
    return input;
}

async function saveEdit(newValue, header, uid) {
    try {
        const token = getAuthToken();
        if (!token) {
            throw new Error('No authentication token found. Please log in again.');
        }

        // Prepare update data with changed_by
        const updateData = {
            [header]: newValue,
            changed_by: getCurrentUserName()
        };
        
        const response = await fetch(getApiUrl(`/api/opportunities/${encodeURIComponent(uid)}`), {
            method: 'PUT',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(updateData)
        });
        
        if (!response.ok) {
            const err = await response.json();
            throw new Error(`Failed to save: ${err.error || response.statusText}`);
        }

        const result = await response.json();
        
        // Update local data
        const index = opportunities.findIndex(opp => opp.uid === uid);
        if (index !== -1) {
            opportunities[index][header] = newValue;
            // Refresh dashboard cards after successful save
            const filteredData = getCurrentFilteredData();
            loadDashboardData(filteredData);
            // Do NOT update the DOM cell here; let makeEditable handle it
        }
        
    } catch (error) {
        console.error("Error saving edit:", error);
        alert(`Error saving: ${error.message}`);
        // Revert cell display to original value
        // (Handled in makeEditable by restoring originalContent on cancel)
    }
}

async function handleEditFormSubmit(e) {
    e.preventDefault();
    
    // Small delay to ensure form is fully populated
    await new Promise(resolve => setTimeout(resolve, 50));
    
    // Get form data
    const formData = new FormData(e.target);
    const opportunityData = {};
    
    // Convert FormData to a regular object
    for (const [key, value] of formData.entries()) {
        opportunityData[key] = value;
    }
    
    console.log('[DEBUG] Form submission - collected data:');
    console.log(opportunityData);
    
    try {
        // For create mode, validate all required fields and use all data
        if (isCreateMode) {
            // Automatically generate encoded_date for new opportunities
            if (!opportunityData.encoded_date) {
                const currentDate = new Date();
                opportunityData.encoded_date = currentDate.toISOString().split('T')[0]; // Format as YYYY-MM-DD
                console.log('[DEBUG] Auto-generated encoded_date:', opportunityData.encoded_date);
            }
            // Remove UID so server generates new one for duplicates
            delete opportunityData.uid;
            
            // Validate all required fields for new records
            let hasError = false;
            const allInputs = e.target.querySelectorAll('input, select, textarea');
            allInputs.forEach(input => input.classList.remove('error'));
            
            // FLEXIBLE VALIDATION: Only require absolutely essential fields
            // Sales people can now save opportunities with minimal information
            const essentialFieldPatterns = [
                {
                    pattern: /project.*name|name.*project|project_name|projectname/i,
                    description: 'Project Name'
                }
                // Note: Removed status requirement - sales can fill this later
            ];
            
            // Optional fields that should be filled eventually (show warning but don't block)
            const recommendedFieldPatterns = [
                {
                    pattern: /^status$|opp.*status|opportunity.*status/i,
                    description: 'Status'
                },
                {
                    pattern: /client/i,
                    description: 'Client'
                }
            ];
            
            let hasEssentialError = false;
            let missingRecommended = [];
            
            // Check essential fields (will block save if missing)
            for (const [fieldName, value] of Object.entries(opportunityData)) {
                for (const essentialPattern of essentialFieldPatterns) {
                    if (essentialPattern.pattern.test(fieldName)) {
                        const isEmpty = !value || (typeof value === 'string' && value.trim() === '');
                        if (isEmpty) {
                            const fieldElement = e.target.querySelector(`[name="${fieldName}"]`);
                            if (fieldElement) {
                                fieldElement.classList.add('error');
                                hasEssentialError = true;
                            }
                        }
                        break;
                    }
                }
            }
            
            // Check recommended fields (will show warning but not block save)
            for (const [fieldName, value] of Object.entries(opportunityData)) {
                for (const recommendedPattern of recommendedFieldPatterns) {
                    if (recommendedPattern.pattern.test(fieldName)) {
                        const isEmpty = !value || (typeof value === 'string' && value.trim() === '');
                        if (isEmpty) {
                            missingRecommended.push(recommendedPattern.description);
                        }
                        break;
                    }
                }
            }
            
            // Block save only if essential fields are missing
            if (hasEssentialError) {
                alert('Please fill in the Project Name field (required).');
                return;
            }
            
            // Show warning for missing recommended fields but allow save to continue
            if (missingRecommended.length > 0) {
                const proceed = confirm(
                    `Warning: The following recommended fields are empty: ${missingRecommended.join(', ')}\n\n` +
                    `You can save now and fill these details later, or click Cancel to complete them now.\n\n` +
                    `Click OK to save anyway, or Cancel to return to the form.`
                );
                if (!proceed) {
                    return; // User chose to go back and fill the fields
                }
            }
            
            // Add metadata
            opportunityData.changed_by = getCurrentUserName();
            
            // Filter out empty string values to avoid server-side validation errors
            // Server expects either valid values or null, not empty strings
            const cleanedData = {};
            for (const [key, value] of Object.entries(opportunityData)) {
                if (value !== null && value !== undefined && value !== '') {
                    cleanedData[key] = value;
                }
            }
            
            console.log('[DEBUG] Cleaned data for server:', cleanedData);
            
            const response = await fetch(getApiUrl('/api/opportunities'), {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                },
                body: JSON.stringify(cleanedData)
            });
            
            if (!response.ok) {
                let errorMessage = 'Failed to create opportunity';
                try {
                    const error = await response.json();
                    if (error.details && Array.isArray(error.details)) {
                        // Show validation errors from express-validator
                        const validationErrors = error.details.map(detail => 
                            `${detail.param}: ${detail.msg}`
                        ).join(', ');
                        errorMessage = `Validation error: ${validationErrors}`;
                    } else if (error.message) {
                        errorMessage = error.message;
                    } else if (error.error) {
                        errorMessage = error.error;
                    }
                } catch (e) {
                    errorMessage = `Server error (${response.status}): ${response.statusText}`;
                }
                console.error('[DEBUG] Server error details:', errorMessage);
                throw new Error(errorMessage);
            }
            
            // Add to opportunities array
            const newOpportunity = await response.json();
            opportunities.unshift(newOpportunity);
            
        } else {
            // For edit mode, only validate and submit changed fields
            const changedFields = {};
            let hasError = false;
            
            // Clear any previous error styling
            const allInputs = e.target.querySelectorAll('input, select, textarea');
            allInputs.forEach(input => input.classList.remove('error'));
            
            console.log('[DEBUG] Starting change-detection validation...');
            console.log('[DEBUG] Original values:', window.originalFormValues);
            console.log('[DEBUG] Current form data:', opportunityData);
            
            // Detect which fields have actually changed
            for (const [fieldName, currentValue] of Object.entries(opportunityData)) {
                const originalValue = window.originalFormValues?.[fieldName] || '';
                const normalizedCurrent = (currentValue || '').toString().trim();
                const normalizedOriginal = (originalValue || '').toString().trim();
                
                if (normalizedCurrent !== normalizedOriginal) {
                    changedFields[fieldName] = currentValue;
                    console.log(`[DEBUG] Field "${fieldName}" changed: "${normalizedOriginal}" -> "${normalizedCurrent}"`);
                }
            }
            
            console.log('[DEBUG] Changed fields:', changedFields);
            
            // If no fields changed, close modal without making API call
            if (Object.keys(changedFields).length === 0) {
                console.log('[DEBUG] No fields changed - closing modal without API call');
                hideEditRowModal();
                return;
            }
            
            // FLEXIBLE VALIDATION FOR EDITS: Only validate essential fields that are being changed
            // Use same flexible approach as create mode
            const essentialFieldPatterns = [
                {
                    pattern: /project.*name|name.*project|project_name|projectname/i,
                    description: 'Project Name'
                }
                // Note: Removed status requirement - sales can clear/change this freely
            ];
            
            const recommendedFieldPatterns = [
                {
                    pattern: /^status$|opp.*status|opportunity.*status/i,
                    description: 'Status'
                },
                {
                    pattern: /client/i,
                    description: 'Client'
                }
            ];
            
            let hasEssentialError = false;
            let clearingRecommended = [];
            
            // Check if any changed essential fields are being set to empty
            for (const [changedFieldName, changedValue] of Object.entries(changedFields)) {
                for (const essentialPattern of essentialFieldPatterns) {
                    if (essentialPattern.pattern.test(changedFieldName)) {
                        console.log(`[DEBUG] Validating changed essential field: ${changedFieldName}`);
                        
                        const isEmpty = !changedValue || (typeof changedValue === 'string' && changedValue.trim() === '');
                        
                        if (isEmpty) {
                            const fieldElement = e.target.querySelector(`[name="${changedFieldName}"]`);
                            if (fieldElement) {
                                fieldElement.classList.add('error');
                                hasEssentialError = true;
                                console.log(`[DEBUG] Essential field "${changedFieldName}" is being cleared - marked as error`);
                            }
                        } else {
                            console.log(`[DEBUG] Essential field "${changedFieldName}" validation PASSED`);
                        }
                        break;
                    }
                }
                
                // Check for recommended fields being cleared (warn but don't block)
                for (const recommendedPattern of recommendedFieldPatterns) {
                    if (recommendedPattern.pattern.test(changedFieldName)) {
                        const isEmpty = !changedValue || (typeof changedValue === 'string' && changedValue.trim() === '');
                        if (isEmpty) {
                            clearingRecommended.push(recommendedPattern.description);
                        }
                        break;
                    }
                }
            }
            
            console.log(`[DEBUG] Flexible validation completed. hasEssentialError: ${hasEssentialError}`);
            
            // Block save only if essential fields are being cleared
            if (hasEssentialError) {
                alert('Cannot clear the Project Name field (required).');
                return;
            }
            
            // Warn about clearing recommended fields but allow save to continue
            if (clearingRecommended.length > 0) {
                const proceed = confirm(
                    `Warning: You are clearing these recommended fields: ${clearingRecommended.join(', ')}\n\n` +
                    `Click OK to save anyway, or Cancel to keep the current values.`
                );
                if (!proceed) {
                    return; // User chose to keep existing values
                }
            }
            
            // Add metadata to changed fields
            const submissionData = {
                ...changedFields,
                changed_by: getCurrentUserName()
            };
            
            console.log('[DEBUG] Submitting only changed data:', submissionData);
            
            // Get UID for update
            const uid = opportunities[currentEditRowIndex]?.uid;
            if (!uid) {
                throw new Error('No UID found for update operation');
            }
            
            console.log(`[DEBUG] Making PUT request to: ${getApiUrl(`/api/opportunities/${uid}`)}`);
            console.log('[DEBUG] Request payload:', JSON.stringify(submissionData, null, 2));
            
            const response = await fetch(getApiUrl(`/api/opportunities/${uid}`), {
                method: 'PUT',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                },
                body: JSON.stringify(submissionData)
            });
            
            console.log(`[DEBUG] Response status: ${response.status} ${response.statusText}`);
            
            if (!response.ok) {
                const error = await response.json();
                console.error('[DEBUG] Error response:', error);
                throw new Error(error.message || `Failed to update opportunity (${response.status})`);
            }
            
            // Update the opportunity in the array with the changed fields
            Object.assign(opportunities[currentEditRowIndex], changedFields);
        }
        
        // Re-render the table with updated data
        filterAndSortData();
        
        // Refresh dashboard cards after successful update
        const filteredData = getCurrentFilteredData();
        loadDashboardData(filteredData);
        
        // Hide the modal
        hideEditRowModal();
        
        // Refresh dashboard data to update counters
        loadDashboardData(filteredData);
        
        // Show success message
        alert(isCreateMode ? 'Opportunity created successfully!' : 'Opportunity updated successfully!');
    } catch (err) {
        alert(`Error: ${err.message}`);
        console.error('Error submitting form:', err);
    }
}

// --- Populate Filter Dropdowns ---
function populateFilterDropdowns() {
    // Clear existing options
    accountMgrFilterDropdown.innerHTML = '<option value="all">All</option>';
    picFilterDropdown.innerHTML = '<option value="all">All</option>';
    if (solutionsFilterDropdown) {
        solutionsFilterDropdown.innerHTML = '<option value="all">All</option>';
    }
    
    // Add options from the data
    if (dropdownOptions.accountmgr) {
        dropdownOptions.accountmgr.forEach(value => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = value;
            accountMgrFilterDropdown.appendChild(option);
        });
    }
    
    if (dropdownOptions.pic) {
        dropdownOptions.pic.forEach(value => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = value;
            picFilterDropdown.appendChild(option);
        });
    }
    
    // Add solutions filter options
    if (solutionsFilterDropdown && dropdownOptions.solutions) {
        dropdownOptions.solutions.forEach(value => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = value;
            solutionsFilterDropdown.appendChild(option);
        });
    }
}

// --- Helper function to abbreviate amounts ---
function abbreviateAmount(value) {
    const absValue = Math.abs(value);
    if (absValue >= 1e9) {
        return '₱' + (value / 1e9).toFixed(1) + 'B';
    }
    if (absValue >= 1e6) {
        return '₱' + (value / 1e6).toFixed(1) + 'M';
    }
    if (absValue >= 1e3) {
        return '₱' + (value / 1e3).toFixed(1) + 'K';
    }
    return '₱' + value.toFixed(2);
}

// --- Load Dashboard Data ---
async function loadDashboardData(dataToUse = null) {
    try {
        // Use filtered data if provided, otherwise fallback to global opportunities
        const opportunitiesData = dataToUse || opportunities;
        
        // Calculate dashboard metrics from the provided data
        const totalOppsCount = opportunitiesData.length;
        
        // Count opportunities by status and calculate amounts
        const op100Opportunities = opportunitiesData.filter(opp => 
            opp.opp_status?.toLowerCase() === 'op100'
        );
        const op100Count = op100Opportunities.length;
        const op100Amount = op100Opportunities.reduce((sum, opp) => 
            sum + (parseCurrency(opp.final_amt) || 0), 0
        );
        
        const op90Opportunities = opportunitiesData.filter(opp => 
            opp.opp_status?.toLowerCase() === 'op90'
        );
        const op90Count = op90Opportunities.length;
        const op90Amount = op90Opportunities.reduce((sum, opp) => 
            sum + (parseCurrency(opp.final_amt) || 0), 0
        );
        
        const inactiveCount = opportunitiesData.filter(opp => 
            opp.opp_status?.toLowerCase() === 'inactive'
        ).length;
        
        const submittedOppsCount = opportunitiesData.filter(opp => 
            opp.status?.toLowerCase() === 'submitted'
        ).length;
        
        // Calculate submitted amount (total of all submitted opportunities)
        const submittedAmount = opportunitiesData.filter(opp => 
            opp.status?.toLowerCase() === 'submitted'
        ).reduce((sum, opp) => sum + (parseCurrency(opp.final_amt) || 0), 0);
        
        const declinedCount = opportunitiesData.filter(opp => 
            opp.decision?.toLowerCase() === 'decline'
        ).length;

        // --- Enhancement: Show difference from last week/month ---
        // Get comparison period preference
        const comparisonMode = localStorage.getItem('dashboardComparisonMode') || 'weekly';
        
        // Get comparison data from PostgreSQL API instead of localStorage
        let comparisonData = {};
        let comparisonLabel = '';
        
        try {
            const snapshotType = comparisonMode === 'weekly' ? 'weekly' : 'monthly';
            const response = await fetch(`/api/snapshots/${snapshotType}`);
            
            if (response.ok) {
                const snapshot = await response.json();
                // Map database format to expected dashboard format
                comparisonData = {
                    totalOpportunities: snapshot.total_opportunities,
                    op100Count: snapshot.op100_count,
                    op90Count: snapshot.op90_count,
                    totalInactive: snapshot.inactive_count,
                    totalSubmitted: snapshot.submitted_count,
                    totalDeclined: snapshot.declined_count
                };
                comparisonLabel = comparisonMode === 'weekly' ? 'vs last week' : 'vs last month';
            }
        } catch (error) {
            console.error('Error fetching snapshot data:', error);
            comparisonData = {};
        }
        
        console.log(`Dashboard comparison mode: ${comparisonMode}`, comparisonData);
        
        // Helper to format value with delta
        function withDelta(current, last, mode = comparisonMode) {
            console.log(`withDelta: current=${current}, last=${last}, mode=${mode}, type=${typeof last}`);
            if (mode === 'none' || typeof last !== 'number') {
                console.log(`withDelta result (no comparison): ${current}`);
                return `${current}`;
            }
            
            const diff = current - last;
            if (diff === 0) return `${current}`;
            const sign = diff > 0 ? '+' : '';
            const result = `${current} (${sign}${diff})`;
            console.log(`withDelta result: ${result}`);
            return result;
        }
        // Update dashboard cards (use correct IDs)
        function setDashboardValue(id, value) {
            const el = document.getElementById(id);
            if (el) {
                console.log(`Setting ${id} to: ${value}`);
                el.textContent = value;
            } else {
                console.warn('Dashboard element not found:', id);
            }
        }
        setDashboardValue('totalOpportunities', withDelta(totalOppsCount, comparisonData.totalOpportunities));
        setDashboardValue('op100Summary', `${withDelta(op100Count, comparisonData.op100Count)} / ${abbreviateAmount(op100Amount)}`);
        setDashboardValue('op90Summary', `${withDelta(op90Count, comparisonData.op90Count)} / ${abbreviateAmount(op90Amount)}`);
        setDashboardValue('totalInactive', withDelta(inactiveCount, comparisonData.totalInactive));
        setDashboardValue('totalSubmitted', withDelta(submittedOppsCount, comparisonData.totalSubmitted));
        setDashboardValue('totalDeclined', withDelta(declinedCount, comparisonData.totalDeclined));

        // Save snapshots based on day of week/month using PostgreSQL API
        const today = new Date();
        const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday
        const dayOfMonth = today.getDate(); // 1-31
        
        const currentSnapshotData = {
            total_opportunities: totalOppsCount,
            submitted_count: submittedOppsCount,
            submitted_amount: submittedAmount, // Correct total submitted amount
            op100_count: op100Count,
            op100_amount: op100Amount,
            op90_count: op90Count,
            op90_amount: op90Amount,
            op60_count: 0, // Calculate if needed
            op60_amount: 0,
            op30_count: 0, // Calculate if needed  
            op30_amount: 0,
            lost_count: 0, // Calculate if needed
            lost_amount: 0,
            inactive_count: inactiveCount,
            ongoing_count: 0, // Calculate if needed
            pending_count: 0, // Calculate if needed
            declined_count: declinedCount,
            revised_count: 0 // Calculate if needed
        };
        
        // Save weekly snapshot on Mondays
        if (dayOfWeek === 1) {
            try {
                await fetch('/api/snapshots', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        snapshot_type: 'weekly',
                        ...currentSnapshotData
                    })
                });
                console.log('Weekly snapshot saved to database (Monday)');
            } catch (error) {
                console.error('Error saving weekly snapshot:', error);
            }
        }
        
        // Save monthly snapshot on the 1st of each month
        if (dayOfMonth === 1) {
            try {
                await fetch('/api/snapshots', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        snapshot_type: 'monthly',
                        ...currentSnapshotData
                    })
                });
                console.log('Monthly snapshot saved to database (1st of month)');
            } catch (error) {
                console.error('Error saving monthly snapshot:', error);
            }
        }
        
        console.log('Dashboard data loaded successfully with PostgreSQL snapshots');
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// --- Dashboard Toggle Helper Functions ---
function setComparisonMode(mode) {
    console.log(`Setting comparison mode to: ${mode}`);
    localStorage.setItem('dashboardComparisonMode', mode);
    updateToggleStates(mode);
    // Reload dashboard data with new comparison mode
    const filteredData = getCurrentFilteredData();
    loadDashboardData(filteredData);
}

function updateToggleStates(activeMode) {
    const buttons = ['weeklyToggle', 'monthlyToggle', 'noCompareToggle'];
    
    buttons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.classList.remove('active');
        }
    });
    
    const activeButtonId = activeMode === 'weekly' ? 'weeklyToggle' :
                         activeMode === 'monthly' ? 'monthlyToggle' : 'noCompareToggle';
    
    const activeBtn = document.getElementById(activeButtonId);
    if (activeBtn) {
        activeBtn.classList.add('active');
    }
}

function saveManualSnapshot() {
    // Get current filtered data for accurate snapshot
    const filteredData = getCurrentFilteredData();
    
    const snapshot = {
        totalOpportunities: filteredData.length,
        op100Count: filteredData.filter(opp => opp.opp_status?.toLowerCase() === 'op100').length,
        op90Count: filteredData.filter(opp => opp.opp_status?.toLowerCase() === 'op90').length,
        totalInactive: filteredData.filter(opp => opp.opp_status?.toLowerCase() === 'inactive').length,
        totalSubmitted: filteredData.filter(opp => 
            opp.opp_status?.toLowerCase() === 'op30' || opp.opp_status?.toLowerCase() === 'op60'
        ).length,
        totalDeclined: filteredData.filter(opp => opp.decision?.toLowerCase() === 'decline').length,
        savedDate: new Date().toISOString()
    };
    
    // Save to both weekly and monthly
    localStorage.setItem('dashboardLastWeek', JSON.stringify(snapshot));
    localStorage.setItem('dashboardLastMonth', JSON.stringify(snapshot));
    
    console.log('Manual snapshot saved:', snapshot);
    alert('Dashboard snapshot saved successfully!');
    
    // Reload dashboard to show updated comparisons with current filtered data
    loadDashboardData(filteredData);
}

function updateSummaryCounters(data) {
    // Update summary counters based on the data
    if (!data) return;

    
    // Calculate counts and amounts
    const op100Opportunities = data.filter(opp => 
        opp.opp_status?.toLowerCase() === 'op100'
    );
    const op100Count = op100Opportunities.length;
    const op100Amount = op100Opportunities.reduce((sum, opp) => 
        sum + (parseCurrency(opp.final_amt) || 0), 0
    );
    
    const op90Opportunities = data.filter(opp => 
        opp.opp_status?.toLowerCase() === 'op90'
    );
    const op90Count = op90Opportunities.length;
    const op90Amount = op90Opportunities.reduce((sum, opp) => 
        sum + (parseCurrency(opp.final_amt) || 0), 0
    );
    
    const inactiveCount = data.filter(opp => 
        opp.opp_status?.toLowerCase() === 'inactive'
    ).length;
    
    const submittedOppsCount = data.filter(opp => 
        opp.status?.toLowerCase() === 'submitted'
    ).length;
    
    const declinedCount = data.filter(opp => 
        opp.decision?.toLowerCase() === 'decline'
    ).length;
    
    const lostCount = data.filter(opp => 
        opp.decision?.toLowerCase() === 'lost'
    ).length;

    // Update the DOM elements if they exist
    if (totalOpportunities) totalOpportunities.textContent = data.length;
    if (op100Summary) op100Summary.textContent = `${op100Count} / ${abbreviateAmount(op100Amount)}`;
    if (op90Summary) op90Summary.textContent = `${op90Count} / ${abbreviateAmount(op90Amount)}`;
    if (totalInactive) totalInactive.textContent = inactiveCount;
    if (totalSubmitted) totalSubmitted.textContent = submittedOppsCount;
       if (totalDeclined) totalDeclined.textContent = declinedCount;
    if (lostSummary) lostSummary.textContent = lostCount;
}

// --- Filter Functions ---
function getActiveFilters() {
    const filters = {
        search: searchInput.value.toLowerCase(),
        status: Array.from(statusFilterButtonsContainer.querySelectorAll('.filter-button.active'))
            .map(btn => btn.dataset.filterValue),
        accountMgr: accountMgrFilterDropdown.value,
        pic: picFilterDropdown.value,
        solutions: solutionsFilterDropdown ? solutionsFilterDropdown.value : 'all'
    };
    return filters;
}

function getActiveFiltersDescription() {
    const filters = getActiveFilters();
    const descriptions = [];
    
    // Status filter
    if (filters.status && filters.status.length > 0 && !filters.status.includes('all')) {
        const statusText = filters.status.map(s => s.toUpperCase()).join(', ');
        descriptions.push(`Status: ${statusText}`);
    }
    
    // Solutions filter
    if (filters.solutions && filters.solutions !== 'all') {
        descriptions.push(`Solutions: ${filters.solutions}`);
    }
    
    // Account Manager filter
    if (filters.accountMgr && filters.accountMgr !== 'all') {
        descriptions.push(`Account Mgr: ${filters.accountMgr}`);
    }
    
    // PIC filter
    if (filters.pic && filters.pic !== 'all') {
        descriptions.push(`PIC: ${filters.pic}`);
    }
    
    // Search filter
    if (filters.search && filters.search.trim()) {
        descriptions.push(`Search: "${filters.search}"`);
    }
    
    return descriptions.length > 0 ? descriptions.join(', ') : '';
}

async function initializeTable() {
    if (!opportunities || !opportunities.length) {
        tableBody.innerHTML = '<tr><td colspan="100%" class="text-center p-4">No data available</td></tr>';
        return;
    }

    // Get headers from the first row and reorder so project_name is first, and remove UID
    let rawHeaders = Object.keys(opportunities[0]);
    console.log(`[DEBUG] Raw headers from database:`, rawHeaders);
    let norm = s => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    let projectNameHeader = rawHeaders.find(h => norm(h) === 'projectname');
    let otherHeaders = rawHeaders.filter(h => norm(h) !== 'projectname' && norm(h) !== 'uid');
    headers = [projectNameHeader, ...otherHeaders].filter(Boolean);
    console.log(`[DEBUG] Final headers for table:`, headers);
    
    // Check if A,C,R,U,D fields are present
    const acrudFields = ['a', 'c', 'r', 'u', 'd'];
    acrudFields.forEach(field => {
        const found = headers.includes(field);
        console.log(`[DEBUG] Field "${field}" present in headers:`, found);
    });

    // Build headerIndices
    headerIndices = {};
    headers.forEach((header, index) => {
        headerIndices[header] = index;
    });

    // Initialize column visibility using user-specific preferences
    try {
        // Try to load user preferences first
        const userPreferences = await loadUserColumnPreferences('opportunities');
        
        if (userPreferences) {
            // User has saved preferences, use them
            columnVisibility = userPreferences;
        } else {
            // No user preferences found, check localStorage for migration
            const stored = localStorage.getItem('columnVisibility');
            if (stored) {
                // Migrate from localStorage
                columnVisibility = JSON.parse(stored);
                await saveUserColumnPreferences('opportunities', columnVisibility);
                localStorage.removeItem('columnVisibility');
            } else {
                // Set and save defaults
                await resetColumnVisibilityToDefaults();
            }
        }
    } catch (error) {
        console.error('Error initializing column visibility:', error);
        // Fallback to legacy localStorage initialization
        if (!localStorage.getItem('columnVisibility')) {
            await resetColumnVisibilityToDefaults();
        } else {
            await initializeColumnVisibility();
        }
    }
    
    // Populate column toggle container
    populateColumnToggleContainer();

    // Populate dropdown options for filters (Account Manager, PIC, etc.)
    dropdownOptions = getDropdownOptions(headers, opportunities);
    populateFilterDropdowns();

    // Apply user-based auto-filtering after dropdowns are populated
    applyAutoFiltersForUser();

    // Initialize table header
    initializeTableHeader();

    // Set default sort by encoded_date in descending order
    const encodedDateIndex = headers.findIndex(header => 
        normalizeField(header) === 'encodeddate'
    );
    if (encodedDateIndex !== -1) {
        currentSortColumnIndex = encodedDateIndex;
        currentSortDirection = 'desc';
        console.log(`[DEBUG] Setting default sort: encoded_date (index ${encodedDateIndex}) in descending order`);
    } else {
        console.warn('[DEBUG] encoded_date column not found for default sorting');
    }

    // Initialize table body
    filterAndSortData();

    // Update sort indicators to show the default sort
    updateSortIndicators();

    // Update row count
    updateRowCount();
}

function initializeTableHeader() {
    const headerRow = document.createElement('tr');
    let visibleColumnIndex = 0; // Track visible column position
    
    headers.forEach((header, index) => {
               // Check if columnVisibility is properly configured - if not, make all columns visible
        if (!columnVisibility) {
            columnVisibility = {};
            headers.forEach(h => columnVisibility[h] = true);
        }
        
        if (!columnVisibility[header]) return; // Only render visible columns
        const th = document.createElement('th');
        
        // Create a container for header content to improve layout
        const headerContent = document.createElement('div');
        headerContent.className = 'header-content';
        headerContent.textContent = formatHeaderText(header);
        
        // Add sort indicator in a separate element for better styling
        const sortIndicator = document.createElement('span');
        sortIndicator.className = 'sort-indicator';
        sortIndicator.innerHTML = '&nbsp;↕';
        headerContent.appendChild(sortIndicator);
        
        th.appendChild(headerContent);
        th.dataset.field = header;
        
        // Set width based on column type
        const columnWidth = getDefaultColumnWidth(header);
        th.style.minWidth = columnWidth;
        th.style.width = columnWidth;
        
        // Add appropriate classes
        if (rightAlignColumns.includes(header.toLowerCase())) {
            th.classList.add('numeric-column');
        }
        
        // Check if this is the project name column (with various possible field names)
        const normalizedHeader = (header || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        const isProjectNameColumn = normalizedHeader === 'projectname' || header.toLowerCase() === 'project_name';
        const isFirstVisibleColumn = visibleColumnIndex === 0;
        
        if (isProjectNameColumn || isFirstVisibleColumn) {
            th.classList.add('project-name-cell');
            // Make project name column sticky
            th.classList.add('sticky-col');
        }
        
        // Check if this is the remarks_comments column
        const normalizedHeaderForRemarks = (header || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        if (normalizedHeaderForRemarks === 'remarkscomments' || header.toLowerCase().includes('remarks')) {
            th.classList.add('remarks-cell');
        }
        // Add click handler for sorting
        th.addEventListener('click', () => handleSortClick(index));
        headerRow.appendChild(th);
        
        visibleColumnIndex++; // Increment visible column counter
    });

    // Add Actions column header with consistent styling
    const actionsHeader = document.createElement('th');
    actionsHeader.textContent = 'Actions';
    actionsHeader.className = 'px-3 py-2 bg-header text-left center-align-cell';
    actionsHeader.style.minWidth = '120px'; // Ensure enough space for the action buttons
    headerRow.appendChild(actionsHeader);

    tableHead.innerHTML = '';
    tableHead.appendChild(headerRow);
}

function formatShortCurrency(num) {
    const prefix = '₱';
    if (num >= 1e9) {
        return prefix + (num / 1e9).toFixed(1) + 'B';
    }
    if (num >= 1e6) {
        return prefix + (num / 1e6).toFixed(1) + 'M';
    }
    if (num >= 1e3) {
        return prefix + (num / 1e3).toFixed(1) + 'K';
    }
    return prefix + num.toFixed(0);
}

function getAuthToken() {
    console.log('[AUTH DEBUG] getAuthToken called');
    const token = localStorage.getItem('authToken');
    console.log('[AUTH DEBUG] Raw token from localStorage:', !!token, token ? token.substring(0, 50) + '...' : 'null');
    
    if (!token) {
        console.log('[AUTH DEBUG] No token found in localStorage');
        return null;
    }
    
    try {
        // Check if token is expired
        const parts = token.split('.');
        console.log('[AUTH DEBUG] Token has', parts.length, 'parts');
        
        const payload = JSON.parse(atob(parts[1]));
        const now = Date.now() / 1000;
        console.log('[AUTH DEBUG] Token payload:', payload);
        console.log('[AUTH DEBUG] Current time:', now, 'Token exp:', payload.exp);
        
        if (payload.exp && payload.exp < now) {
            console.log('[AUTH DEBUG] Token expired, removing from localStorage');
            localStorage.removeItem('authToken');
            return null;
        }
        console.log('[AUTH DEBUG] Token is valid, expires in', payload.exp - now, 'seconds');
        return token;
    } catch (error) {
        console.error('[AUTH DEBUG] Invalid token format, removing from localStorage:', error);
        localStorage.removeItem('authToken');
        return null;
    }
}

function getCurrentUserName() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) {
            console.warn('[getCurrentUserName] No token found');
            return 'Unknown User';
        }
        
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.name || payload.username || payload.email || 'Unknown User';
    } catch (error) {
        console.error('[getCurrentUserName] Error parsing token:', error);
        return 'Unknown User';
    }
}

function showAuthErrorBanner(message) {
    console.log('[AUTH DEBUG] Showing error banner:', message);
    const banner = document.getElementById('authErrorBanner');
    if (banner) {
        banner.innerHTML = message; // Changed from textContent to innerHTML
        banner.style.display = 'block';
        setTimeout(() => {
            banner.style.display = 'none';
        }, 10000); // Increased timeout to 10 seconds
    } else {
        console.error('[AUTH DEBUG] authErrorBanner element not found in DOM');
        // Create a fallback banner if the element doesn't exist
        const fallbackBanner = document.createElement('div');
        fallbackBanner.style.cssText = `
            position: fixed; top: 10px; left: 10px; right: 10px; z-index: 9999;
            background: #ff6b6b; color: white; padding: 15px; border-radius: 5px;
            font-family: Arial, sans-serif; font-size: 14px;
        `;
        fallbackBanner.innerHTML = message;
        document.body.appendChild(fallbackBanner);
        
        setTimeout(() => {
            if (fallbackBanner.parentNode) {
                fallbackBanner.parentNode.removeChild(fallbackBanner);
            }
        }, 10000);
    }
}

// --- Validation Functions ---
function validateEmail(email) {
    return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

function validatePassword(password) {
    return typeof password === 'string' && password.length >= 8 && password.length <= 100;
}

// Helper function to enable horizontal scrolling with mousewheel
function setupHorizontalScroll() {
    const tableContainer = document.querySelector('.table-container');
    const scrollIndicator = document.querySelector('.scroll-indicator');
    
    if (tableContainer) {
        // FIXED: Only enable horizontal scroll when SHIFT+wheel or when primarily horizontal movement
        tableContainer.addEventListener('wheel', function(e) {
            // Only intercept if shift is held
            if (e.shiftKey) {
                e.preventDefault();
                
                // Use deltaY for shift+wheel, deltaX for normal horizontal wheel
                const scrollAmount = e.shiftKey ? e.deltaY : e.deltaX;
                const scrollSpeed = Math.min(80, Math.abs(scrollAmount) * 0.8);
                this.scrollLeft += scrollAmount > 0 ? scrollSpeed : -scrollSpeed;
                
                // Add visual feedback for horizontal scrolling
                tableContainer.classList.add('scrolling');
                setTimeout(() => {
                    tableContainer.classList.remove('scrolling');
                }, 300);
            }
            // Let vertical scrolling work normally for all other cases
        }, { passive: false });
        
        // Hide scroll indicator when we reach the end of the table
        tableContainer.addEventListener('scroll', function() {
            if (scrollIndicator) {
                const maxScroll = this.scrollWidth - this.clientWidth;
                const scrollPosition = this.scrollLeft;
                
                // If we're near the end of the scroll area
                if (scrollPosition > maxScroll - 20) {
                    scrollIndicator.style.opacity = '0';
                } else {
                    scrollIndicator.style.opacity = '0.8';
                }
            }
        });
        
        // Update scroll indicator visibility on window resize
        window.addEventListener('resize', function() {
            if (scrollIndicator) {
                if (tableContainer.scrollWidth <= tableContainer.clientWidth) {
                    // No horizontal scroll needed
                    scrollIndicator.style.display = 'none';
                } else {
                    scrollIndicator.style.display = 'block';
                }
            }
        });
        
        // Initial check
        setTimeout(() => {
            if (scrollIndicator) {
                if (tableContainer.scrollWidth <= tableContainer.clientWidth) {
                    scrollIndicator.style.display = 'none';
                } else {
                    scrollIndicator.style.display = 'block';
                }
            }
        }, 1000); // Wait for table to fully render
    }
}

setupHorizontalScroll();

// --- Reset Table Function ---
function resetTable() {
    // Clear search input
    if (searchInput) {
        searchInput.value = '';
    }
    
    // Reset status filter buttons
    const activeStatusButtons = document.querySelectorAll('.filter-button.active');
    activeStatusButtons.forEach(button => {
        button.classList.remove('active');
    });
    // Set 'All' as active after clearing
    const allStatusButton = document.querySelector('.filter-button[data-filter-value="all"]');
    if (allStatusButton) {
        allStatusButton.classList.add('active');
    }
    
    // Reset dropdown filters
    if (accountMgrFilterDropdown) {
        accountMgrFilterDropdown.value = 'all';
    }
    
    if (picFilterDropdown) {
        picFilterDropdown.value = 'all';
    }
    
    if (solutionsFilterDropdown) {
        solutionsFilterDropdown.value = 'all';
    }
    
    // Re-render the table with all data
    filterAndSortData();
    
    // Update dashboard cards since Account Manager and Solutions filters were reset
    updateSummaryCounters(opportunities);
}

async function initializeColumnVisibility() {
    // Default hidden columns (specific columns that should be hidden on initial load for new users)
    const defaultHiddenColumns = [
        'description', 'comments', 'uid', 'created_at', 'updated_at', 
        'encoded_date', 'a', 'c', 'r', 'u', 'd', 'rev', 'project_code',
        'sol_particulars', 'ind_particulars', 'lost_rca', 'l_particulars',
        'client_deadline', 'submitted_date', 'date_awarded_lost', 'forecast_date'
    ];
    
    let visibilitySettings = {};
    
    try {
        // Try to load user-specific preferences from server
        const userPreferences = await loadUserColumnPreferences('opportunities');
        
        if (userPreferences) {
            // User has saved preferences, use them
            visibilitySettings = userPreferences;
        } else {
            // No user preferences found, check localStorage as fallback
            const stored = localStorage.getItem('columnVisibility');
            if (stored) {
                visibilitySettings = JSON.parse(stored);
                // Migrate localStorage preferences to user-specific storage
                await saveUserColumnPreferences('opportunities', visibilitySettings);
                // Clear localStorage after migration
                localStorage.removeItem('columnVisibility');
            } else {
                // Set defaults if no stored preferences
                headers.forEach(header => {
                    const shouldHide = defaultHiddenColumns.some(col => 
                        header.toLowerCase() === col.toLowerCase()
                    );
                    visibilitySettings[header] = !shouldHide;
                });
                
                // Save default settings to user-specific storage
                await saveUserColumnPreferences('opportunities', visibilitySettings);
            }
        }
    } catch (e) {
        console.error('Error loading column preferences:', e);
        // Fallback to localStorage for backward compatibility
        try {
            const stored = localStorage.getItem('columnVisibility');
            if (stored) {
                visibilitySettings = JSON.parse(stored);
            } else {
                // Set defaults
                headers.forEach(header => {
                    const shouldHide = defaultHiddenColumns.some(col => 
                        header.toLowerCase() === col.toLowerCase()
                    );
                    visibilitySettings[header] = !shouldHide;
                });
            }
        } catch (fallbackError) {
            // Final fallback to showing all columns
            headers.forEach(header => {
                visibilitySettings[header] = true;
            });
        }
    }
    
    // Apply visibility settings
    columnVisibility = visibilitySettings;
}

// Function to reset column visibility to defaults
async function resetColumnVisibilityToDefaults() {
    // Default hidden columns (specific columns that should be hidden on initial load for new users)
    const defaultHiddenColumns = [
        'description', 'comments', 'uid', 'created_at', 'updated_at', 
        'encoded_date', 'a', 'c', 'r', 'u', 'd', 'rev', 'project_code',
        'sol_particulars', 'ind_particulars', 'lost_rca', 'l_particulars',
        'client_deadline', 'submitted_date', 'date_awarded_lost', 'forecast_date'
    ];
    
    let visibilitySettings = {};
    
    if (headers && headers.length > 0) {
        // Set defaults based on headers
        headers.forEach(header => {
            const shouldHide = defaultHiddenColumns.some(col => 
                header.toLowerCase() === col.toLowerCase()
            );
            visibilitySettings[header] = !shouldHide;
        });
    } else {
        console.warn('Headers not available for resetColumnVisibilityToDefaults');
        return;
    }
    
    // Apply visibility settings
    columnVisibility = visibilitySettings;
    
    // Save to localStorage as fallback
    localStorage.setItem('columnVisibility', JSON.stringify(visibilitySettings));
    
    try {
        // Save to user-specific storage if authenticated
        await saveUserColumnPreferences('opportunities', visibilitySettings);
    } catch (error) {
        console.error('Error saving default column preferences to server:', error);
    }
    
    console.log('Column visibility reset to defaults');
}

async function resetUserColumnPreferences(pageName) {
    try {
        const token = getAuthToken();
        if (!token) {
            console.warn('Cannot reset column preferences: not authenticated');
            return false;
        }
        
        const response = await fetch(getApiUrl(`/api/user-column-preferences/${pageName}`), {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`Failed to reset column preferences: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('Column preferences reset successfully:', data.message);
        return true;
    } catch (error) {
        console.error('Error resetting user column preferences:', error);
        return false;
    }
}

function populateColumnToggleContainer() {
    if (!columnToggleContainer || !headers || headers.length === 0) {
        return;
    }
    
    // Clear the container
    columnToggleContainer.innerHTML = '';
    
    // Create toggle controls for each column
    headers.forEach((header, index) => {
        // Skip actions column - it should always be visible
        if (header.toLowerCase() === 'actions') {
            return;
        }
        
        // Create a wrapper div for the checkbox and label
        const wrapper = document.createElement('div');
        wrapper.className = 'flex items-center gap-2';
        
        // Create checkbox
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `column-toggle-${index}`;
        checkbox.dataset.columnName = header;
        checkbox.checked = columnVisibility[header] ?? true;
        
        // Disable the first visible column (usually project name) to prevent hiding it
        const isFirstVisibleColumn = headers.findIndex(h => columnVisibility[h] !== false) === index;
        if (isFirstVisibleColumn) {
            checkbox.disabled = true;
            checkbox.title = 'First column cannot be hidden';
        }
        
        // Create label
        const label = document.createElement('label');
        label.htmlFor = `column-toggle-${index}`;
        label.textContent = formatHeaderText(header);
        label.className = 'text-sm select-none';
        
        // Add change event listener
        checkbox.addEventListener('change', async function() {
            // Update column visibility
            columnVisibility[header] = this.checked;
            
            // Save to user-specific preferences with localStorage fallback
            await saveUserColumnPreferences('opportunities', columnVisibility);
            
            // Rebuild table with new visibility settings
            initializeTableHeader();
            filterAndSortData();
            
            // Update disabled state of first visible column checkbox
            updateFirstVisibleColumnState();
        });
        
        // Append elements to wrapper
        wrapper.appendChild(checkbox);
        wrapper.appendChild(label);
        
        // Add wrapper to container
        columnToggleContainer.appendChild(wrapper);
    });
    
    // Update disabled state for the first visible column
    updateFirstVisibleColumnState();
}

function updateFirstVisibleColumnState() {
    if (!columnToggleContainer || !headers) return;
    
    // Find the first visible column
    const firstVisibleIndex = headers.findIndex(h => columnVisibility[h] !== false);
    
    // Enable all checkboxes first
    columnToggleContainer.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
        checkbox.disabled = false;
        checkbox.title = '';
    });
    
    // Disable the first visible column checkbox
    if (firstVisibleIndex >= 0) {
        const firstVisibleHeader = headers[firstVisibleIndex];
        const firstVisibleCheckbox = columnToggleContainer.querySelector(`input[data-column-name="${firstVisibleHeader}"]`);
        if (firstVisibleCheckbox) {
            firstVisibleCheckbox.disabled = true;
            firstVisibleCheckbox.title = 'First visible column cannot be hidden';
        }
    }
}

// --- User Column Preferences Functions ---
async function loadUserColumnPreferences(pageName) {
    try {
        const token = getAuthToken();
        if (!token) {
            return null; // Not authenticated, can't load user preferences
        }
        
        const response = await fetch(getApiUrl(`/api/user-column-preferences/${pageName}`), {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) {
            if (response.status === 404 || response.status === 401) {
                return null; // No preferences found or not authenticated
            }
            throw new Error(`Failed to load column preferences: ${response.statusText}`);
        }
        
        const data = await response.json();
        return data.columnSettings;
    } catch (error) {
        console.error('Error loading user column preferences:', error);
        return null; // Fall back to localStorage or defaults
    }
}

async function saveUserColumnPreferences(pageName, columnSettings) {
    try {
        const token = getAuthToken();
        if (!token) {
            console.warn('Cannot save column preferences: not authenticated');
            return false;
        }
        
        const response = await fetch(getApiUrl(`/api/user-column-preferences/${pageName}`), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ columnSettings })
        });
        
        if (!response.ok) {
            throw new Error(`Failed to save column preferences: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('Column preferences saved successfully:', data.message);
        return true;
    } catch (error) {
        console.error('Error saving user column preferences:', error);
        // Fallback to localStorage for backward compatibility
        try {
            localStorage.setItem('columnVisibility', JSON.stringify(columnSettings));
            console.warn('Saved to localStorage as fallback');
        } catch (localStorageError) {
            console.error('Failed to save to localStorage as fallback:', localStorageError);
        }
        return false;
    }
}

// --- Dashboard Toggles Initialization ---
function initializeDashboardToggles() {
    console.log('[AUTH DEBUG] initializeDashboardToggles called');
    try {
        // Initialize toggle states based on saved comparison mode
        const savedMode = localStorage.getItem('dashboardComparisonMode') || 'weekly';
        console.log('[AUTH DEBUG] Initializing toggle states with mode:', savedMode);
        
        // Update toggle button states
        updateToggleStates(savedMode);
        
        console.log('[AUTH DEBUG] Dashboard toggles initialized successfully');
    } catch (error) {
        console.error('[AUTH DEBUG] Error in initializeDashboardToggles:', error);
    }
}

// --- User-Based Auto-Filtering Functions ---

// Get current user roles from JWT token
function getCurrentUserRoles() {
    try {
        const token = localStorage.getItem('authToken');
        if (!token) {
            console.warn('[getCurrentUserRoles] No token found');
            return [];
        }
        
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.roles || [];
    } catch (error) {
        console.error('[getCurrentUserRoles] Error parsing token:', error);
        return [];
    }
}

// Map user roles to appropriate filter values
function mapUserRolesToFilters(userRoles, availableData) {
    const filters = {};
    
    if (!userRoles || userRoles.length === 0 || !availableData) {
        return filters;
    }
    
    console.log('[ROLE-FILTER] Mapping roles:', userRoles);
    
    // Get available filter values from data
    const accountMgrs = Array.from(new Set(availableData.map(item => item.account_mgr || item['account_mgr']).filter(Boolean)));
    const solutions = Array.from(new Set(availableData.map(item => item.solutions).filter(Boolean)));
    const pics = Array.from(new Set(availableData.map(item => item.pic).filter(Boolean)));
    
    // Role-based filtering logic
    userRoles.forEach(role => {
        switch(role.toUpperCase()) {
            case 'DS':
                // DS (Data Solutions) - filter by specific solutions
                const dsFilters = solutions.filter(sol => 
                    sol.toLowerCase().includes('data') || 
                    sol.toLowerCase().includes('analytics') ||
                    sol.toLowerCase().includes('intelligence') ||
                    sol.toLowerCase().includes('ds')
                );
                if (dsFilters.length > 0) {
                    filters.solutions = dsFilters[0]; // Use first matching solution
                    console.log('[ROLE-FILTER] DS role mapped to solutions filter:', filters.solutions);
                }
                break;
                
            case 'SE':
                // SE (Sales Engineer) - could filter by specific account managers or technical solutions
                const seFilters = solutions.filter(sol => 
                    sol.toLowerCase().includes('engineering') || 
                    sol.toLowerCase().includes('technical') ||
                    sol.toLowerCase().includes('se')
                );
                if (seFilters.length > 0) {
                    filters.solutions = seFilters[0];
                    console.log('[ROLE-FILTER] SE role mapped to solutions filter:', filters.solutions);
                }
                break;
                
            case 'SALES':
                // Sales role - filter by account manager matching current user
                const userName = getCurrentUserName();
                console.log('[ROLE-FILTER] SALES role - checking for account manager filter for user:', userName);
                
                if (userName && userName !== 'Unknown User') {
                    // Try to match current user to an account manager
                    const accountMgrMatch = mapUserNameToFilterValue(userName, accountMgrs);
                    if (accountMgrMatch) {
                        filters.accountManager = accountMgrMatch;
                        console.log('[ROLE-FILTER] SALES role mapped to account manager filter:', filters.accountManager);
                    } else {
                        console.log('[ROLE-FILTER] SALES role - no account manager match found for user:', userName);
                    }
                } else {
                    console.log('[ROLE-FILTER] SALES role - no valid user name found');
                }
                break;
                
            case 'ADMIN':
                // Admin - full access, no filtering
                console.log('[ROLE-FILTER] ADMIN role - no filtering applied');
                break;
                
            default:
                console.log('[ROLE-FILTER] Unknown role:', role);
        }
    });
    
    return filters;
}

function mapUserNameToFilterValue(userName, availableValues) {
    if (!userName || !availableValues || availableValues.length === 0) {
        return null;
    }
    
    const userLower = userName.toLowerCase();
    
    // Direct exact match first
    const exactMatch = availableValues.find(value => 
        value.toLowerCase() === userLower
    );
    if (exactMatch) return exactMatch;
    
    // Check if user name contains email, extract initials
    if (userLower.includes('@')) {
        const emailPrefix = userLower.split('@')[0];
        const parts = emailPrefix.split('.');
        if (parts.length >= 2) {
            const initials = parts.map(part => part.charAt(0).toUpperCase()).join('');
            const initialsMatch = availableValues.find(value => 
                value.toLowerCase().includes(initials.toLowerCase())
            );
            if (initialsMatch) return initialsMatch;
        }
    }
    
    // Check if userName contains parts of any available values
    const partialMatch = availableValues.find(value => {
        const valueParts = value.toLowerCase().split(/[\s\._\-]+/);
        const userParts = userLower.split(/[\s\._\-@]+/);
        
        return valueParts.some(vPart => 
            userParts.some(uPart => 
                uPart.length > 1 && (vPart.includes(uPart) || uPart.includes(vPart))
            )
        );
    });
    if (partialMatch) return partialMatch;
    
    // Check if any available value contains parts of userName
    const containsMatch = availableValues.find(value => {
        const valueWords = value.toLowerCase().split(/[\s\._\-]+/);
        const userWords = userLower.split(/[\s\._\-@]+/);
        
        return userWords.some(userWord => 
            userWord.length > 2 && valueWords.some(valueWord => 
                valueWord.includes(userWord) || userWord.includes(valueWord)
            )
        );
    });
    
    return containsMatch || null;
}

function applyAutoFiltersForUser() {
    try {
        // First try role-based filtering
        const userRoles = getCurrentUserRoles();
        console.log('[AUTO-FILTER] Checking role-based auto-filter for roles:', userRoles);
        
        if (userRoles && userRoles.length > 0 && opportunities && opportunities.length > 0) {
            const roleFilters = mapUserRolesToFilters(userRoles, opportunities);
            let roleFilterApplied = false;
            
            // Apply role-based solutions filter
            if (roleFilters.solutions && solutionsFilterDropdown) {
                console.log('[AUTO-FILTER] Applying role-based solutions filter:', roleFilters.solutions);
                solutionsFilterDropdown.value = roleFilters.solutions;
                roleFilterApplied = true;
            }
            
            // Apply role-based account manager filter
            if (roleFilters.accountManager && accountMgrFilterDropdown) {
                console.log('[AUTO-FILTER] Applying role-based account manager filter:', roleFilters.accountManager);
                accountMgrFilterDropdown.value = roleFilters.accountManager;
                roleFilterApplied = true;
            }
            
            if (roleFilterApplied) {
                console.log('[AUTO-FILTER] Role-based auto-filter applied, refreshing data...');
                filterAndSortData();
                // Dashboard cards UPDATE when role-based filters are applied
                const filteredData = getCurrentFilteredData();
                updateSummaryCounters(filteredData);
                return; // Exit early if role-based filtering was applied
            }
        }
        
        // Fallback to username-based filtering if no role-based filtering was applied
        const userName = getCurrentUserName();
        console.log('[AUTO-FILTER] Checking username-based auto-filter for user:', userName);
        
        if (!userName || userName === 'Unknown User') {
            console.log('[AUTO-FILTER] No valid user found, skipping auto-filter');
            return;
        }
        
        // Check if we have dropdown data available
        if (!dropdownOptions || (!dropdownOptions.accountmgr && !dropdownOptions.pic)) {
            console.log('[AUTO-FILTER] Dropdown options not ready yet, skipping auto-filter');
            return;
        }
        
        let filterApplied = false;
        
        // Try to match Account Manager first
        if (dropdownOptions.accountmgr && accountMgrFilterDropdown) {
            const accountMgrMatch = mapUserNameToFilterValue(userName, dropdownOptions.accountmgr);
            if (accountMgrMatch) {
                console.log('[AUTO-FILTER] Applying Account Manager filter:', accountMgrMatch);
                accountMgrFilterDropdown.value = accountMgrMatch;
                filterApplied = true;
            }
        }
        
        // If no Account Manager match, try PIC
        if (!filterApplied && dropdownOptions.pic && picFilterDropdown) {
            const picMatch = mapUserNameToFilterValue(userName, dropdownOptions.pic);
            if (picMatch) {
                console.log('[AUTO-FILTER] Applying PIC filter:', picMatch);
                picFilterDropdown.value = picMatch;
                filterApplied = true;
            }
        }
        
        // Apply the filters if any were set
        if (filterApplied) {
            console.log('[AUTO-FILTER] Username-based auto-filter applied, refreshing data...');
            filterAndSortData();
            // Dashboard cards UPDATE when account manager or PIC filters are applied
            const filteredData = getCurrentFilteredData();
            updateSummaryCounters(filteredData);
        } else {
            console.log('[AUTO-FILTER] No matching filter found for user:', userName);
        }
        
    } catch (error) {
        console.error('[AUTO-FILTER] Error applying auto-filter:', error);
    }
}