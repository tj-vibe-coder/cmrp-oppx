/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./app.js",
    "./*.html",
    "./*.js"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
